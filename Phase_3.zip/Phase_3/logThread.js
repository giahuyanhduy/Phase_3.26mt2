const fs = require('fs');
const moment = require("moment");
if (!fs.existsSync('./logs')) {
    fs.mkdirSync('./logs');
}
if (!fs.existsSync('./logapp')) {
    fs.mkdirSync('./logapp');
}
 
function writeLogCaBom() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_chotCa.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}

function writeLogPROCESSQUEUEKIT() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_PROCESSQUEUEKIT.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}

function writeLogQueue() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_Queue.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}
function writeLogMaBom() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_maBom.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}

function writeLogHanmuc() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_Hanmuc.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}

function writeLogSendToKIT() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_SendToKIT.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}
function writeLogReceivedFromKIT() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_ReceivedFromKIT.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}
function writeLogDoiGia() {
    if (!arguments.length)
        return;
    console.log(Object.values(arguments))
    const path = `./logapp/${moment().format('DD-MM-YYYY')}_doiGia.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}
function writeLog() {
    const path = `${__dirname}/logs/${moment().format('DD-MM-YYYY')}.log`;
    const time = moment().format('DD-MM-YYYY HH:mm:ss');
    if (fs.existsSync(path)) {
        fs.appendFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)} \r\n`, function (err) {
            if (err)
                return console.error(err);

        });
    } else {

        fs.writeFile(path, `[${time}]:  ${JSON.stringify(Object.values(arguments), null, 4)}`, {flag: 'wx'}, function (err) {
            if (err)
                return console.error(err);

        });
    }
}
 
module.exports = {
    writeLog,
    writeLogDoiGia,
    writeLogMaBom,
    writeLogCaBom ,
	writeLogReceivedFromKIT,
	writeLogSendToKIT,
	writeLogQueue,
	writeLogPROCESSQUEUEKIT,
    writeLogHanmuc
}