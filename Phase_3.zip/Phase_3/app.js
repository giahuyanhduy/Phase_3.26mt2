require("console-stamp")(console, {
  pattern: "dd/mm/yyyy HH:MM:ss.l",
  metadata: function () {
    return "[" + process.memoryUsage().rss + "]";
  },
  colors: {
    stamp: "yellow",
    label: "red",
    metadata: "green",
  },
});
const {
  writeLog,
  writeLogCaBom,
  writeLogDoiGia,
  writeLogMaBom,
} = require("./logThread");
const { init } = require("./helper/pool");
init(initApp);
const utils = require("./utils");
function initApp() {
  //
  //const ver = "3.1.0";
  //const ver_releasedate = "23/06/2021";

  const moment = require("moment");
  const cors = require("cors");
  const Helper = require("./helper");
  const Gas = require("./Gas");
  const GasControler = require("./GasController");
  const express = require("express");
  const bodyParser = require("body-parser");
  const fs = require("fs");
  const PORT = 6969;
  const app = express();
  const server = require("http").Server(app);
  const io = require("socket.io")(server);
  const socketIOClient = require("socket.io-client");
  const asteriskIO = socketIOClient(
    "http://servicekit.thietbixangdauhoanglong.com:8002"
  );

  server.listen(PORT, () => {
    writeLog(`Server listen on port ${PORT}`);
  });

  let IDCT = 0;

  app.use(cors());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(bodyParser.json());
  var listPort = null;
  let MAC = "";

  var os = require("os");
  var networkInterfaces = os.networkInterfaces();
  var net = networkInterfaces.Ethernet || networkInterfaces["Ethernet 2"];
  var serialPortModule = require("serialport");
  let gas = null;

  //13/05/2021 : TRUONGNM : Them get thong tin o cung
  var diskspace = require("./diskspace.js");

  let guidungluongocung = () => {
    var drive_letter = "/";
    try {
      diskspace.check(drive_letter, function (err, result) {
        console.log("KIT_THONGTINOCUNG", GasControler.CONFIG.getIDCT(), result);
        if (GasControler.CONFIG.getIDCT() && GasControler.CONFIG.getIDCT() > 0)
          asteriskIO.emit(
            "KIT_THONGTINOCUNG",
            GasControler.CONFIG.getIDCT(),
            MAC,
            result
          );

        writeLog("KIT_THONGTINOCUNG", GasControler.CONFIG.getIDCT(), result);
      });
    } catch (ex) {}
  };

  let capnhattimezone = () => {
    try {
      console.log("capnhattimezone");
      var exec = require("child_process").exec;

      // any unix based command

      var cmdToLaunch = "timedatectl set-timezone Asia/Ho_Chi_Minh";

      function execCB(error, stdout, stderr) {
        if (error) {
          writeLog("timedatectl error", error);
        }
        console.log("timedatectl change ", stdout, stderr, error);
        writeLog("timedatectl change ", stdout, stderr, error);
      }

      var app = exec(cmdToLaunch, execCB);
    } catch (e) {
      writeLog("timedatectl error", e);
    }
  };

  guidungluongocung();
  setInterval(() => {
    guidungluongocung();
  }, 60 * 1000 * 30); //10 phut
  //END gui thong tin o cung

  setInterval(() => {
    //luu vao get fulldate
    gas = GasControler.getGasData(0);
  }, 1000);

  asteriskIO.once("connect", function () {
    writeLog("ketnoi socket server");
    console.log("ketnoi socket server");
    capnhattimezone();
    let home_dir = "";

    try {
      var exec = require("child_process").exec;

      var cmdToLaunch = "ls /root";

      function execCB(error, stdout, stderr) {
        home_dir = stdout;
        asteriskIO.emit("start_kit", stdout, stderr, error);
        console.log("start_kit: " + stdout);
        console.log("start_kit: " + stderr);

        if (net) {
          net.forEach((item) => {
            if (item.family == "IPv4") {
              try {
                /*
							serialPortModule.list().then(ports => {
							listPort = ports;
								
							});
							*/
                MAC = item.mac;

                asteriskIO.emit(
                  "kitGetIDCT",
                  net,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  "connect_socket_" + home_dir
                );
                console.log(
                  "emit kitGetIDCT",
                  net,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  null
                );
                writeLog(
                  "emit kitGetIDCT",
                  net,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  null
                );
              } catch (e) {
                console.log(e);
                writeLog(e);
              }
            }
          });
        } else {
          // asteriskIO.emit(
            // "kitGetIDCT",
            // "ERROR:networkInterfaces.Ethernet hoac Ethernet 2 null",
            // "",
            // "",
            // "connect_socket_" + home_dir
          // );
          writeLog("ERROR:networkInterfaces.Ethernet hoac Ethernet 2 null");
          Object.keys(networkInterfaces).forEach(function (ifname) {
            var alias = 0;
            try {
              /*
							serialPortModule.list().then(ports => {
							listPort = ports;
									  
							  
							});
							*/

              networkInterfaces[ifname].forEach(function (iface) {
                if ("IPv4" !== iface.family || iface.internal !== false) {
                  // skip over internal (i.e. 127.0.0.1) and non-ipv4 addresses
                  return;
                }

                if (alias >= 1) {
                  // this single interface has multiple ipv4 addresses
                  console.log(
                    ifname + ":" + alias,
                    iface.address + "- mac : " + iface.mac
                  );
                  MAC = iface.mac;

                  asteriskIO.emit(
                    "kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    "connect_socket_" + home_dir
                  );
                  console.log(
                    "emit kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    null
                  );
                  writeLog(
                    "emit kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    null
                  );
                } else {
                  // this interface has only one ipv4 adress
                  console.log(ifname, iface.address + "- mac : " + iface.mac);
                  MAC = iface.mac;
                  asteriskIO.emit(
                    "kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    "connect_socket_" + home_dir
                  );
                  console.log(
                    "emit kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    null
                  );
                  writeLog(
                    "emit kitGetIDCT",
                    iface,
                    MAC,
                    GasControler.CONFIG.getCOM(),
                    null
                  );
                }
                ++alias;
              });
            } catch (e) {
              console.log(e);
              writeLog(e);
            }
          });
        }
      }

      var app = exec(cmdToLaunch, execCB);
    } catch (e) {
      writeLog("ls error", e);
    }

    asteriskIO.on("kitGetIDCT", (data) => {
      writeLog("kitGetIDCT", data);
      console.log("kitGetIDCT", data);
      if (data) {
        IDCT = data;
        if (IDCT > 0) {
          GasControler.CONFIG.setIDCT(IDCT);
          writeLog("kitGetIDCT", IDCT);
          asteriskIO.emit(
            "subscribeKIT",
            IDCT,
            MAC,
            GasControler.CONFIG.getCOM()
          );
        }
      }
    });

    setInterval(() => {
      if (IDCT && IDCT > 0)
        asteriskIO.emit(
          "subscribeKIT",
          GasControler.CONFIG.getIDCT(),
          MAC,
          GasControler.CONFIG.getCOM()
        );
    }, 60 * 1000 * 60);

    asteriskIO.on("subscribeKIT", (data) => {
      writeLog("on subscribeKIT", data);
      if (GasControler.CONFIG.getIDCT() && GasControler.CONFIG.getIDCT() > 0) {
        asteriskIO.emit(
          "subscribeKIT",
          GasControler.CONFIG.getIDCT(),
          MAC,
          GasControler.CONFIG.getCOM()
        );
      }
    });

    asteriskIO.on("requestKITGetIDCT", (data) => {
      writeLog("requestKITGetIDCT", data);
      console.log("requestKITGetIDCT", data);

      // try
      // {
      // serialPortModule.list(function (err, ports) {
      // listPort = ports;

      // });
      // }
      // catch(e)
      // {
      // writeLog(e);
      // }

      if (net) {
        writeLog(net);
        net.forEach((item) => {
          if (item.family == "IPv4") {
            MAC = item.mac;
            console.log(
              "emit kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
            asteriskIO.emit(
              "kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
            writeLog(
              "emit kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
          }
        });
      } else {
        asteriskIO.emit(
          "kitGetIDCT",
          "ERROR:networkInterfaces.Ethernet hoac Ethernet 2 null",
          "",
          "",
          null
        );
        writeLog("ERROR:networkInterfaces.Ethernet hoac Ethernet 2 null");
        Object.keys(networkInterfaces).forEach(function (ifname) {
          var alias = 0;
          try {
            networkInterfaces[ifname].forEach(function (iface) {
              if ("IPv4" !== iface.family || iface.internal !== false) {
                // skip over internal (i.e. 127.0.0.1) and non-ipv4 addresses
                return;
              }

              if (alias >= 1) {
                // this single interface has multiple ipv4 addresses
                console.log(
                  ifname + ":" + alias,
                  iface.address + "- mac : " + iface.mac
                );
                MAC = iface.mac;

                asteriskIO.emit(
                  "kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
                console.log(
                  "emit kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
                writeLog(
                  "emit kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
              } else {
                // this interface has only one ipv4 adress
                console.log(ifname, iface.address + "- mac : " + iface.mac);
                MAC = iface.mac;
                asteriskIO.emit(
                  "kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
                console.log(
                  "emit kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
                writeLog(
                  "emit kitGetIDCT",
                  iface,
                  MAC,
                  GasControler.CONFIG.getCOM(),
                  listPort
                );
              }
              ++alias;
            });
          } catch (e) {
            console.log(e);
            writeLog(e);
          }
        });
      }
    });

    setInterval(() => {
      try {
        // serialPortModule.list(function (err, ports) {
        // listPort = ports;
        // });
      } catch (e) {
        writeLog(e);
        try {
          writeLog("TREO_PORT_KHOI_DONG_LAI_MAY");
          var exec = require("child_process").exec;

          // any unix based command

          var cmdToLaunch = "reboot";

          function execCB(error, stdout, stderr) {
            if (error) {
              writeLog("rebootKITServer error", error);
              asteriskIO.emit("rebootKITServer", data, stdout, stderr, error);
              return;
            }
            writeLog("KHOI_DONG_LAI_MAY", data, stdout, stderr, error);
            asteriskIO.emit("rebootKITServer", data, stdout, stderr, error);
          }

          var app = exec(cmdToLaunch, execCB);
        } catch (e) {
          writeLog("rebootKITServer error", e);
        }
      }
      if (net) {
        writeLog(net);
        net.forEach((item) => {
          if (item.family == "IPv4") {
            MAC = item.mac;
            console.log(
              "emit kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
            asteriskIO.emit(
              "kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
            writeLog(
              "emit kitGetIDCT",
              net,
              MAC,
              GasControler.CONFIG.getCOM(),
              listPort
            );
          }
        });
      } else {
		  writeLog("KIT_ERROR_KHONGLAYDUOC_THONGTINCARDMANG", listPort);  
			// asteriskIO.emit(
			  // "kitGetIDCT",
			  // "KIT_ERROR_KHONGLAYDUOC_THONGTINCARDMANG",
			  // "",
			  // "",
			  // listPort
			// );
      }
    }, 5 * 60 * 1000); //5 phut cap nhat get IDCT 1 lan

    asteriskIO.on("getFullUpdateKIT", (data) => {
      //console.log('getFullUpdateKIT', data);

      let obj = {};
      obj.data = gas;
      obj.idct = GasControler.CONFIG.getIDCT();
      obj.updateTime = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      obj.ver = GasControler.ver;
      obj.ver_releasedate = GasControler.ver_releasedate;
      //nsole.log('getFullUpdateKIT', obj);

      asteriskIO.emit("getFullUpdateKIT", obj);
    });

    asteriskIO.on("changePriceKIT", (data) => {
      console.log("changePriceKIT", data);
      writeLog("changePriceKIT", data);
      let ret = {};
      ret.idct = GasControler.CONFIG.getIDCT();
      ret.startTime = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      ret.message = "Co loi xay ra";
      ret.status = false;
      ret.metro = data.metro;

      ret.price = data.price;

      if (data) {
        writeLog("#changePrice", data);

        GasControler.changePriceMetro(data.metro, data.price, (msg) => {
          writeLog("#changePrice", msg);

          ret.idct = GasControler.CONFIG.getIDCT();
          ret.endTime = moment
            .parseZone(new Date())
            .format("DD/MM/YYYY HH:mm:ss");
          ret.dataReturn = msg;
          ret.message = "Doi gia thanh cong";
          ret.status = true;
        });
      }
      ret.endTime = moment.parseZone(new Date()).format("DD/MM/YYYY HH:mm:ss");
      writeLog("changePriceKIT return to Server : ", ret);
      asteriskIO.emit("changePriceKIT", ret);
    });

    asteriskIO.on("chotcaKIT", (data) => {
      console.log("chotcaKIT", data);
      writeLog("chotcaKIT", data);
      let ret = {};
      ret.idct = GasControler.CONFIG.getIDCT();
      ret.startTime = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      ret.message = `Có lỗi xảy ra`;
      if (data) {
        let pump = GasControler.CONFIG.getComNameFromId(data.idCot);
        if (pump)
          GasControler.chotca(+data.idCot, pump.com, (json) => {
            ret.idct = GasControler.CONFIG.getIDCT();
            ret.endTime = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
            ret.dataReturn = json;
            ret.message = "Chot ca thanh cong";
            ret.status = true;
          });
        else {
          ret.status = false;
          ret.idct = GasControler.CONFIG.getIDCT();

          ret.message = `Có lỗi xảy ra với pump reqbody:${JSON.stringify(
            data
          )}`;
        }
      }
      ret.endTime = moment.parseZone(new Date()).format("DD/MM/YYYY HH:mm:ss");
      writeLog("chotcaKIT return to Server : ", ret);
      asteriskIO.emit("chotcaKIT", ret);
    });

    asteriskIO.on("daylaidulieuKIT", (data) => {
      console.log("daylaidulieuKIT data", data);

      if (data) {
        let pump = GasControler.CONFIG.getComNameFromId(data.idCot);
        if (pump) GasControler.daylaidulieuthieuMaBom(+data.idCot, pump.com);
      }
    });

    asteriskIO.on("daylaidulieuKIT_CaBom", (data) => {
      console.log("daylaidulieuKIT_CaBom data", data);

      if (data) {
        let pump = GasControler.CONFIG.getComNameFromId(data.idCot);
        if (pump) GasControler.daylaidulieuthieuCaBom(+data.idCot, pump.com);
      }
    });

    asteriskIO.on("daylaidulieuthieu", (data) => {
      console.log("daylaidulieuthieu", data);
      writeLog("daylaidulieuthieu", data);
      GasControler.daylaidulieuthieu();
    });

    asteriskIO.on("daylaidulieuthieuCa", (data) => {
      console.log("daylaidulieuthieuCa", data);
      writeLog("daylaidulieuthieuCa", data);
      GasControler.daylaidulieuthieuCa();
    });

    asteriskIO.on("getQUEUE_SEND_TO_KIT_V2", (data) => {
      console.log("getQUEUE_SEND_TO_KIT_V2", data);
      writeLog("getQUEUE_SEND_TO_KIT_V2", data);
      asteriskIO.emit(
        "getQUEUE_SEND_TO_KIT_V2",
        data,
        GasControler.getQUEUE_SEND_TO_KIT_V2(0)
      );
    });

    asteriskIO.on("rebootKITServer", (data) => {
      writeLog("rebootKITServer", data);
      try {
        var exec = require("child_process").exec;

        // any unix based command

        var cmdToLaunch = "reboot";
        asteriskIO.emit("on_rebootKITServer_kit_rebooting", data);
        function execCB(error, stdout, stderr) {
          if (error) {
            console.error(`exec error: ${error}`);
            writeLog("rebootKITServer error", error);
            asteriskIO.emit("rebootKITServer", data, stdout, stderr, error);
            return;
          }
          asteriskIO.emit("rebootKITServer", data, stdout, stderr, error);
          console.log("stdout: " + stdout);
          console.log("stderr: " + stderr);
        }

        var app = exec(cmdToLaunch, execCB);
      } catch (e) {
        writeLog("rebootKITServer error", e);
      }
    });
    var http = require("http");
    var fs = require("fs");

    function pDownload(url, dest) {
      try {
        console.log("Downloading..." + url);
        writeLog("Downloading..." + url);

        const http = require("http");
        const fs = require("fs");

        const request = http.get(url, function (response) {
          if (response.statusCode === 200) {
            var file = fs.createWriteStream(dest);
            response.pipe(file);
            writeLog("Downloading done");
            console.log("Downloading done");

            //reboot
            try {
              var exec = require("child_process").exec;

              // any unix based command

              var cmdToLaunch = "reboot";

              function execCB(error, stdout, stderr) {
                if (error) {
                  console.error(`exec error: ${error}`);
                  writeLog("rebootKITServer error", error);

                  return;
                }
              }

              var app = exec(cmdToLaunch, execCB);
            } catch (e) {
              writeLog("rebootKITServer error", e);
            }
          }
          request.setTimeout(60000, function () {
            // if after 60s file not downlaoded, we abort a request
            request.abort();
          });
        });
      } catch (e) {}
    }

    asteriskIO.on("capnhatserverkit", (data) => {
      writeLog("capnhatserverkit", data);
      try {
        asteriskIO.emit("KITphanhoicapnhatserverkit", data);
        //example
        pDownload(data.url, data.location);
      } catch (e) {
        writeLog("capnhatserverkit error", e);
      }
    });

    asteriskIO.on("execKITServer", (data) => {
      writeLog("execKITServer", data);
      try {
        var exec = require("child_process").exec;

        // any unix based command

        var cmdToLaunch = data.query;

        function execCB(error, stdout, stderr) {
          if (error) {
            writeLog(`exec error: ${error}`);
            asteriskIO.emit("execKITServer", data, stdout, stderr, error);
            return;
          }
          asteriskIO.emit("execKITServer", data, stdout, stderr, error);
          writeLog("stdout: " + stdout);
          writeLog("stderr: " + stderr);
        }

        var app = exec(cmdToLaunch, execCB);
      } catch (e) {
        writeLog("execKITServer error", e);
      }
    });
  });

  io.on("connection", (client) => {
    var socketId = client.id;
    var clientIp = client.request.connection.remoteAddress;
    console.log("connection :", client.request.connection._peername);

    var address = client.handshake.address;
    writeLog("New connection from " + address.address + ":" + address.port);
    writeLog("Ket noi tu IP : ", clientIp);

    client.on("getFullUpdate", () => {
      let gas = null; //let gas = GasControler.getGasData(0);
      client.emit("getFullUpdate", gas);
    });
    client.on("getFullUpdate1", () => {
      let gas = null; //let gas = GasControler.getGasData(1);
      client.emit("getFullUpdate1", gas);
    });

    // client.on('getFullUpdateKIT', (data) => {
    // console.log('getFullUpdateKIT', data);

    // let gas = 'ok';//let gas = GasControler.getGasData(0);
    // client.emit("getFullUpdateKIT", gas)

    // });

    client.on("subscribe", (data) => {
      writeLog("subscribe", data);
      // let obj;
      // if (typeof data == 'string') {
      // obj = JSON.parse(data)
      // } else {
      // obj = data
      // }
      // let {maccAddress, iDCT} = obj;

      client.join(data);
    });

    client.on("getthongtinocung", (data) => {
      client.emit("getthongtinocung", thongTinOCung);
    });
  });

  app.get("/getFullUpdate", (req, res) => {
    let gas = GasControler.getGasData(1);
    res.send(gas);
  });

  app.get("/getFullUpdateArr", (req, res) => {
    let gas = GasControler.getGasData(0);
    res.send(gas);
  });

  app.get("/daylaidulieuthieu", (req, res) => {
    GasControler.daylaidulieuthieu();
    res.send("ok");
  });
  
//GIANG TEST API
  app.get("/daylaidulieu/:id", (req, res) => {
	if (req.params.id) {
        let pump = GasControler.CONFIG.getComNameFromId(req.params.id);
        if (pump) GasControler.daylaidulieuthieuMaBom(+req.params.id, pump.com);
    }
  
    res.send("OK");
  });
//END
  
  app.get("/metro/:type", (req, res) => {
    res.send(GasControler.getAllPumpByMetroType(req.params.type));
  });
  app.post("/changePrice", (req, res) => {
    writeLog("#changePrice", req.body);
    let { metro, price } = req.body;
    GasControler.changePriceMetro(metro, price, (msg) => {
      writeLog("#changePrice", msg);
      res.json({ status: true, msg });
    });
  });
  app.get("/db", (req, res) => {
    res.send(GasControler.getDebugData(0));
  });

  app.get("/getQUEUE_PENDING", (req, res) => {
    res.send(GasControler.getQUEUE_PENDING(0));
  });

  app.get("/getQUEUE_SEND_TO_KIT_V2", (req, res) => {
    res.send(GasControler.getQUEUE_SEND_TO_KIT_V2(0));
  });

  app.get("/getQUEUE_SEND_TO_KIT", (req, res) => {
    res.send(GasControler.getQUEUE_SEND_TO_KIT(0));
  });

  app.get("/testSend", (req, res) => {
    try {
      const request = require("request");

      request.post(
        "http://118.70.171.240:8322/api/kit/themmabom",
        {
          json: {
            thoigian: "2020-05-08 10:27:00",
            sotien: 0,
            soluong: 0,
            idCot: 0,
            pos: 0,
            idhang: 0,
            mabomht: 0,
            starttime: "2020-05-08 10:27:00",
            id1: 0,
            id2: 0,
            idct: 0,
          },
        },
        (error, resq, body) => {
          if (error) {
            console.error(error);
            return;
          }
          res.json({ status: true, msg: "" });

          console.log(`statusCode: ${res.statusCode}`);
          console.log(body);
        }
      );
    } catch (ex) {
      console.log(ex);
    }
  });

  app.get("/metroConfig", (req, res) => {
    let arr = Object.values(GasControler.CONFIG.getMetroName("all"));
    res.json(
      arr.map((i) => {
        return { value: i };
      })
    );
  });
  app.get("/getCaBomIDCot/:id", (req, res) => {
    let id = req.params.id;
    Helper.selectCaBomByIdCot(id, (err, data) => {
      res.json({ err, data });
    });
  });
  app.get("/tienchuachotca/:id", (req, res) => {
    let id = req.params.id;
    Helper.selectDsChotCaChuaChotNgay(id, (data) => {
      res.send(data);
    });
  });
  app.post("/chotca", (req, res) => {
    let { idCot } = req.body;
    let pump = GasControler.CONFIG.getComNameFromId(idCot);
    if (pump)
      GasControler.chotca(+idCot, pump.com, (json) => {
        res.json(json);
      });
    else {
      res.json({
        status: false,
        msg: `Có lỗi xảy ra với pump reqbody:${JSON.stringify(req.body)}`,
      });
    }
  });

  app.get("/install", function (req, res) {
    res.download("./app-release.apk", "smartgas.apk");
  });

  app.get("/getCaBomFromKITIDCot/:idCot", function (req, res) {
    res.json({ status: true, msg: 1 });
  });

  let sendDataToRoom = (room, data = "", event, isLog = true) => {
    console.log("sendDataToRoom", room);
    try {
      room = String(room);
      if (isHaveConnectToRoom(room)) {
        if (io.sockets.adapter.rooms[room].length) {
          io.to(room).emit(event, data);
        } else {
          if (isLog) {
            console.log(`room ${room} khong co ai de event ${event}`);
            writeLog(`room ${room} khong co ai de event ${event}`);
          }
        }
      } else {
        if (isLog) {
          console.log(`room ${room} khong co ai de event ${event}`);
          writeLog(`room ${room} khong co ai de event ${event}`);
        }
      }
    } catch (ex) {
      console.log(ex);
      writeLog(ex);
      return false;
    }
  };

  let isHaveConnectToRoom = (room) => {
    try {
      room = String(room);
      if (io.sockets.adapter.rooms[room]) {
        return Boolean(io.sockets.adapter.rooms[room].length);
      } else {
        return false;
      }
    } catch (ex) {
      writeLog(ex);
      return false;
    }
  };

  function xoamabom60ngay() {
    const cronJob = require("cron").CronJob;
    const job = new cronJob("00 00 00 * * * ", () => {
      writeLog("SCHEDULE", "XOADULIEULUUQUA60NGAY");
      //04/08/2021 : TRUONGNM
      try {
        var exec = require("child_process").exec;

        // any unix based command

        var cmdToLaunch = "find /home/giang/Phase_3/mabom/ -mtime +60 -delete";

        function execCB(error, stdout, stderr) {
          if (error) {
            writeLog(`exec error: ${error}`);
          }

          writeLog("stdout: " + stdout);
          writeLog("stderr: " + stderr);
        }

        var app = exec(cmdToLaunch, execCB);
      } catch (e) {
        writeLog("execKITServer error", e);
      }
    });

    job.start();
    writeLog("SCHEDULE", "RUN_JOB_XOADULIEU60NGAY");
  }
  xoamabom60ngay();
}
