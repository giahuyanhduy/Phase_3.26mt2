const sql = require("mssql");
const pool = require("./pool").getPool();
const moment = require("moment");

const MAX_PUMP_RETRY = process.env.MAX_PUMP || 5;

const API_URL = "http://apikit.thietbixangdauhoanglong.com:8102";
const API_QUEUE_URL = "http://apikitv2.thietbixangdauhoanglong.com:8012";


const utils = require("../utils");
const CONFIG = require("../config");

function selectDsChotCaChuaChotNgay(idcot, callback) {
  try {
    pool
      .request()
      .input("idCot", sql.Int, idcot)
      .execute("usp_HaoHT_CaBom_selectChuaChotCa")
      .then((result) => {
        callback(null, result.recordset);
      })
      .catch((err) => {
        callback(err);
      });
  } catch (e) {}
}

var fs = require("fs");
const { writeLog, writeLogMaBom } = require("../logThread");
var dataMaBomChuaGui = {};
var dataCaBomChuaGui = {};
let dangchaydaymabomchuagui = false;
setInterval(() => {
  //check co mang se gui ca bom va ma bom chua gui duoc

  if (!dangchaydaymabomchuagui) {
    //day ma bom
    dangchaydaymabomchuagui = true;

    let folderpath = "./mabomchuagui/";
    let folderpathCabom = "./cabomchuagui/";

    readFiles(
      folderpath,
      function (filename, content) {
        dataMaBomChuaGui[filename] = content;
      },
      function (err) {}
    );

    readFiles(
      folderpathCabom,
      function (filename, content) {
        dataCaBomChuaGui[filename] = content;
      },
      function (err) {}
    );

    if (
      dataMaBomChuaGui &&
      Object.keys(dataMaBomChuaGui).length > 0 &&
      CONFIG.getIDCT() > 0
    ) {
      try {
        let url = API_URL + "/api/kit/themmabom";
        //let url = API_QUEUE_URL + "/them-ma-bom";

        const http = require("http");
        var request = http
          .get(url, (resp) => {
            let data = "";
            request.setTimeout(3000, function () {
              // handle timeout here

              console.log("server ma bom timeout");
            });
            // A chunk of data has been recieved.
            resp.on("data", (chunk) => {
              data += chunk;
            });

            // The whole response has been received. Print out the result.
            resp.on("end", () => {
              console.log("server ma bom ok");
              //duyet cac ma bom chua gui de gui len he thong :

              for (let i of Object.keys(dataMaBomChuaGui)) {
                console.log(i);

                //let mabom = dataMaBomChuaGui[i];
                try {
                  let mabom = JSON.parse(dataMaBomChuaGui[i]);

                  mabom.idct = CONFIG.getIDCT();
                  insertMaBom(mabom, (err, dt) => {
                    const pathToFile = folderpath + i;
                    try {
                      fs.unlinkSync(pathToFile);
                      console.log("Successfully deleted the file.", i);
                    } catch (err) {
                      //throw err
                    }
                  });
                  console.log(mabom);
                } catch (e) {
                  console.log(e);
                  console.log(dataMaBomChuaGui[i]);

                  const pathToFile = folderpath + i;
                  try {
                    fs.unlinkSync(pathToFile);
                    console.log("Successfully deleted the file.", i);
                  } catch (err) {
                    //throw err
                  }
                }
              }
            });
          })
          .on("error", (err) => {
            console.log("Error: " + err.message);
          });
      } catch (ex) {
        console.log(ex);
      }
      dataMaBomChuaGui = {};
    }

    //ca bom
    if (
      dataCaBomChuaGui &&
      Object.keys(dataCaBomChuaGui).length > 0 &&
      CONFIG.getIDCT() > 0
    ) {
      try {
        let url = API_URL + "/api/kit/themcabom";

        const http = require("http");
        var request = http
          .get(url, (resp) => {
            let data = "";
            request.setTimeout(3000, function () {
              // handle timeout here

              console.log("server ca bom timeout");
            });
            // A chunk of data has been recieved.
            resp.on("data", (chunk) => {
              data += chunk;
            });

            // The whole response has been received. Print out the result.
            resp.on("end", () => {
              console.log("server ca bom ok");
              //duyet cac ma bom chua gui de gui len he thong :

              for (let i of Object.keys(dataCaBomChuaGui)) {
                console.log(i);

                //let cabom = dataCaBomChuaGui[i];
                try {
                  let cabom = JSON.parse(dataCaBomChuaGui[i]);
                  cabom.idct = CONFIG.getIDCT();
                  insertCaBom(cabom, (err, dt) => {
                    const pathToFile = folderpathCabom + i;
                    try {
                      fs.unlinkSync(pathToFile);
                      console.log("Successfully deleted the file.", i);
                      console.log("cabom insert ok ", cabom);
                    } catch (err) {
                      //  throw err
                    }
                  });
                } catch (err) {
                  //  throw err
                  const pathToFile = folderpathCabom + i;
                  try {
                    fs.unlinkSync(pathToFile);
                    console.log("Successfully deleted the file.", i);
                    console.log("cabom insert ok ", cabom);
                  } catch (err) {
                    //  throw err
                  }
                }
              }
            });
          })
          .on("error", (err) => {
            console.log("Error: " + err.message);
          });
      } catch (ex) {
        console.log(ex);
      }
      dataCaBomChuaGui = {};
    }

    dangchaydaymabomchuagui = false;
  }
  //console.log(dataMaBomChuaGui);
}, 1000);

function readFiles(dirname, onFileContent, onError) {
  try {
    fs.readdir(dirname, function (err, filenames) {
      if (err) {
        onError(err);
        return;
      }
      filenames.forEach(function (filename) {
        fs.readFile(dirname + filename, "utf-8", function (err, content) {
          if (err) {
            onError(err);
            return;
          }
          onFileContent(filename, content);
        });
      });
    });
  } catch (e) {}
}

function capNhatGiaBan(idCot, donGia, idCa) {
  return new Promise((resolve, reject) => {
    try {
      const request = require("request");
      let baseURL = API_URL;
      let idct = CONFIG.getIDCT();
      let url = baseURL + "/api/kit/capnhatgiaban";
      let params = {
        ID_QLLH: idct,
        ID_Cot: idCot,
        DonGia: donGia,
        ID_Ca: idCa,
      };
      writeLog("CAPNHATGIABAN CALL API", url, params);
      if (idct > 0) {
        let options = {
          method: "POST",
          url: url,
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(params),
        };
        request(options, (error, response) => {
          if (error) {
            reject(error);
          } else {
            resolve(response);
          }
        });
      } else {
        resolve({ flag: false, msg: "Khong co IDCT" });
      }
    } catch (err) {
      reject(err);
    }
  });
}

function getListcotbomThieuMaBom(cb) {
  try {
    const request = require("request");
    let url = API_URL;
    let idct = CONFIG.getIDCT();
    if (idct > 0) {
      request.get(
        url + "/api/kit/getlistcotbomkhonglientiep",
        null,
        (error, resq, body) => {
          if (error) {
            utils.writeLog("getListcotbomThieuMaBom", error);
            if (cb) {
              cb(null);
            }
          } else {
            if (cb) {
              var arr = JSON.parse(body);
              if (arr.length < 1) return cb(null, null);
              var filter = arr.filter((value, index, arr) => {
                return value.ID_QLLH == idct;
              });
              cb(null, filter);
            }
          }
        }
      );
    }
  } catch (ex) {
    utils.writeLog("getListcotbomThieuMaBom", ex);
    console.log(ex);
    cb(null);
  }
}

function getHanmuc(RFID, idcotbom, callback) {
  try {
    const request = require("request");
    let url = API_URL;
    let idct = CONFIG.getIDCT();
    if (idct > 0) {
      request.get(
        url +
          "/api/kiemtrahanmuc/hanmucrfid?RFID=" +
          RFID +
          "&ID_VOIBOM=" +
          idcotbom +
          "&ID_QLLH=" +
          idct,
        null,
        (error, resq, body) => {
          if (error) {
            utils.writeLog(error);
            callback(null);
          } else {
            if (callback) {
              callback(null, JSON.parse(body));
            }
          }
        }
      );
    }
  } catch (ex) {
    console.log(ex);
    callback(null);
  }
}

function writeMaBomChuaGui(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./mabomchuagui/")) {
      fs.mkdirSync("./mabomchuagui/");
    }

    const path =
      "./mabomchuagui/" +
      idcot +
      "_" +
      stt +
      "_" +
      moment(obj.date).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {}
}

function writeCaBomChuaGui(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./cabomchuagui/")) {
      fs.mkdirSync("./cabomchuagui/");
    }

    const path =
      "./cabomchuagui/" +
      idcot +
      "_" +
      stt +
      "_" +
      moment(obj.thoigian).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {}
}

function insertMaBom(obj, callback) {
	 console.log("*********insertMaBom**************",obj);
  let {
    idca,
    idcot,
    money,
    mili,
    date,
    pump,
    pos,
    startTime,
    id1,
    id2,
    idct,
    gia,
  } = obj;
 console.log("****",obj.pos,MAX_PUMP_RETRY);
//GIANG TEST
if (obj.pos <= MAX_PUMP_RETRY){ 

  try {
    const request = require("request");

    //let url = API_URL + "/api/kit/themmabom";
    let url = API_QUEUE_URL  + '/them-ma-bom';
    request.post(
      url,

      {
        json: {
          idca: idca,
          thoigian: moment(date).format("YYYY-MM-DD HH:mm:ss"),
          sotien: money,
          soluong: mili,
          idCot: idcot,
          pos: pos,
          idhang: 0,
          mabomht: pump,
          starttime: moment(startTime).format("YYYY-MM-DD HH:mm:ss"),
          id1: id1,
          id2: id2,
          idct: idct,
          gia: gia,
        },
      },
      (error, resq, body) => {
        writeLogMaBom(
          "#xuLyDayMaBom|idcot:" + idcot + "|pos:" + pos,
          body,
          error,
          obj
        );
        if (error) {
          utils.writeLog(
            "#xuLyDayMaBom|ERROR|idcot:" + idcot + "|pos:" + pos,
            error
          );
          writeLogMaBom(
            "#xuLyDayMaBom|ERROR|idcot:" + idcot + "|pos:" + pos,
            error
          );
          writeMaBomChuaGui(idcot, pump, obj);
          callback(error, null);
        } else {
          callback(null, "OK");
        }
      }
    );
  } catch (ex) {
    utils.writeLog("#xuLyDayMaBom|ERROR|idcot:" + idcot + "|pos:" + pos, ex);
    writeLogMaBom("#xuLyDayMaBom|ERROR|idcot:" + idcot + "|pos:" + pos, ex);
    writeMaBomChuaGui(idcot, pump, obj);
    console.log(ex);
    callback(ex, null);
  }
  }else{
	  console.log("****************************************************");
  }
}

function insertCaBom(caObj, callback) {
  let {
    idcot,
    idca,
    somabom,
    mabomtiep,
    thoigian,
    lit,
    gia,
    thanhtien,
    totaltichluy,
    totalcare,
    pos,
    metroId,
    idct,
  } = caObj;
  
  //GIANG TEST 
	const now = moment();
	const m_date = moment(thoigian,'YYYY-DD-MM HH:mm:ss');
	if (now.diff(m_date, 'days') > 30) {
		console.log(now);
		console.log(m_date);
        console.warn('****** ca bơm sai hơn thời gian hiện tại quá 30 ngày! ******');
		return null;
    } else {
        //console.log('******** Thời gian ca bơm hợp lệ *************');
    }


  try {
    const request = require("request");
    let url = API_URL + "/api/kit/themcabom";

    request.post(
      url,
      {
        json: {
          idct: idct,
          idcot: idcot,
          idca: idca,
          somabom: somabom,
          mabomtiep: mabomtiep,
          thoigian: moment(thoigian).format("YYYY-MM-DD HH:mm:ss"),
          lit: lit,
          gia: gia,
          thanhtien: thanhtien,
          totaltichluy: totaltichluy,
          totalcare: totalcare,
          pos: pos,
          metroId: metroId,
        },
      },
      (error, resq, body) => {
        if (error) {
          utils.writeLog(error);
          writeCaBomChuaGui(idcot, idca, caObj);
          callback(null);
        } else {
          callback(null, "OK");
        }
      }
    );
  } catch (ex) {
    console.log(ex);
    callback(null);
  }
}

module.exports = {
  selectDsChotCaChuaChotNgay,
  insertCaBom,
  insertMaBom,
  getHanmuc,
  capNhatGiaBan,
  getListcotbomThieuMaBom,
};
