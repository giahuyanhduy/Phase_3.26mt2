const GAS = require("./Gas");
const Helper = require("./helper");
const { CMD, ADDR, StatusBom } = require("./const");
const { numberToBCD, saveMaBomCurrent, getCurrentMaBom } = require("./utils");
const utils = require("./utils");

const MAX_PUMP_RETRY = process.env.MAX_PUMP || 5;

const CONFIG = require("./config");
const GAS_DATA = {};
const ALL_PUMP = CONFIG.getAllPump("arr");
const eventEmitter = require("./eventEmitter");
//const timeOutArray = [200, 300, 400, 500, 1000, 2000, 4000, 8000, 10000, 15000];
const timeOutArray = [200];
const {
  writeLogHanmuc,
  writeLog,
  writeLogCaBom,
  writeLogDoiGia,
  writeLogMaBom,
  writeLogReceivedFromKIT,
  writeLogSendToKIT,
  writeLogPROCESSQUEUEKIT,
  writeDonGiaHienTai,
  readDonGiaHienTai,
  writeLogTimeOut,
} = require("./logThread");
const moment = require("moment");
const { exec } = require("child_process");
//version
const ver = "3.2.26+";
const ver_releasedate = "31/10/2024";
//3.2.26 : Fix loi khi idca = 0 bi treo khong gui len
//3.2.25 : Fix don gia bi loi khi null
//3.2.24 : Fix don gia cap nhat realtime sau khi doi gia
//3.2.23 : Fix don gia cap nhat realtime sau khi doi gia
//3.2.22 : Cap nhat ban co thong tin gia va IdCa trong ma bom
//3.2.21 : Ban KTC25
//3.2.20 : doi sang server test
//3.2.19 : validate doi gia va them logs
//3.2.18 : doi sang link queue tren sv moi dung domain
//3.2.17 : doi sang link queue tren sv moi dung IP
//3.2.9 : doi link dung queue
//3.2.7 : 06/12/2022 : TRUONGNM sua chi lay ma thieu den 350 (qua gio han luu cua KIT)
//3.2.4 : TRUONGNM fix:bo ham getlastcabom trong xu ly xuLyDuLieuNewRfid
//3.2.6 : Bo sung xoa logapp va logs cua ManhLD

setThoiGianKit_KhiChayKit();
//22/06/2021 : BO CHAY 5 phut lay 10 ma bom day len he thong
testrun();
//daylaidulieuthieu();
for (let i of ALL_PUMP) {
  /// Khởi động sẽ lấy giá đã lưu trên file text
  readDonGiaHienTai(i.id, (err, don_gia) => {
    // Đọc từ file
    if (err) console.log("ReadDonGiaHienTai Error: ", i.id, err);
    let obj = GAS_DATA[i.id];
    if (!obj) {
      obj = GAS_DATA[i.id] = {};
    }
    obj["dongia"] = don_gia;
    getQuickUpdate(i); // đọc idca bom hien tai
  });
}

function setDonGiaHienTai(idcot, don_gia) {
  let obj = GAS_DATA[idcot];
  if (!obj) {
    obj = GAS_DATA[idcot] = {};
  }
  obj["dongia"] = don_gia;
  writeDonGiaHienTai(idcot, don_gia);
}

function setThoiGianKit_KhiChayKit() {
  for (let i of ALL_PUMP) {
    let obj = GAS_DATA[i.id];
    if (!obj) {
      obj = GAS_DATA[i.id] = { timeOut: 0 };
    }
    if (!obj.isDisconnected && obj.timeOut == 0) {
      setThoiGianKit_ByKitId(i);
    }
  }
}

setInterval(() => {
  setThoiGianKit_KhiChayKit();
  // setThoiGianKit();
}, 10 * 60 * 1000);

function daylaidulieuthieu() {
  writeLog("daylaidulieuthieu");

  let arr = Object.values(GAS_DATA);
  if (arr) {
    for (let a of arr) {
      if (!a.isDisconnected && a.id && a.com) {
        //daylaidulieuKIT(a.id, a.com);
        if (GAS_DATA[a.id]) {
          if (GAS_DATA[a.id].getmabomthieu) {
            if (GAS_DATA[a.id].getmabomthieu.runstatus != 1) {
              //1 : dang chay get ma bom thieu
              daylaidulieuKIT(a.id, a.com);
            } else {
              writeLog(
                "daylaidulieuthieu => KHONG chay do dang chay roi",
                a.id,
                a.com
              );
            }
          } else {
            writeLog("daylaidulieuthieu", a.id, a.com);
            daylaidulieuKIT(a.id, a.com);
          }
        }
      }
    }
  }
}

function daylaidulieuthieuCa() {
  writeLog("daylaidulieuthieuCa");

  let arr = Object.values(GAS_DATA);
  if (arr) {
    for (let a of arr) {
      if (!a.isDisconnected && a.id && a.com) {
        writeLog("daylaidulieuthieuCa", a.id, a.com);
        daylaidulieuthieuCaBom(a.id, a.com);

        // if(GAS_DATA[a.id])
        // {
        // if(GAS_DATA[a.id].getmabomthieu)
        // {
        // if(GAS_DATA[a.id].getmabomthieu.runstatus != 1 ) //1 : dang chay get ma bom thieu
        // {
        // writeLog("daylaidulieuthieuCa", a.id, a.com);
        // daylaidulieuthieuCaBom(a.id, a.com);
        // }
        // else{
        // writeLog("daylaidulieuthieuCa => KHONG chay do dang chay roi", a.id, a.com);
        // }
        // }
        // else
        // {
        // writeLog("daylaidulieuthieuCa", a.id, a.com);
        // daylaidulieuthieuCaBom(a.id, a.com);
        // }
        // }
      }
    }
  }
}

function daylaidulieuKIT(id, com) {
  writeLog("daylaidulieuKIT", id, com);
  //handleCaBom(id, com);
  //handleMaBom(id, com, 0);
  //daylaidulieuthieuCaBom(id, com);
  daylaidulieuthieuMaBom(id, com);
}

//03/08/2021 : TRUONGNM sua
function daylaidulieuthieuMaBom(id, com) {
  if (GAS_DATA[id]) {
    //co roi kiem tra
    let getmabomthieu = {
      thoigianbatdau: moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss"),
      thoigianketthuc: null,
      com: com,
      idcot: id,
      pos: 0,
      msg: "Dang xu ly get ma bom",
      runstatus: 0,
      thoigian_guilenhKIT: null,
      thoigian_KITPhanHoi: null,
      mabom: null,
      error: null,
    };

    if (GAS_DATA[id].getmabomthieu) {
      if (GAS_DATA[id].getmabomthieu.runstatus != 1) {
        //1 : dang chay get ma bom thieu
        //chua chay hoac da chay xong thi moi chay
        GAS_DATA[id].getmabomthieu = getmabomthieu;
        writeLog("daylaidulieuthieuMaBom", id, com);
        handleMaBom(id, com, 0);
      } else {
        writeLog(
          "daylaidulieuthieuMaBom => KHONG chay do dang chay roi",
          id,
          com
        );
      }
    } else {
      GAS_DATA[id].getmabomthieu = getmabomthieu;
      writeLog("daylaidulieuthieuMaBom", id, com);
      handleMaBom(id, com, 0);
    }
  }
}
//03/08/2021 : TRUONGNM sua
function daylaidulieuthieuCaBom(id, com) {
  writeLog("daylaidulieuthieuCaBom", id, com);
  handleCaBom(id, com);
}

//ManhLD them
deleteLog();

//ManhLD goi Job xoa log
function deleteLog() {
  const cronJob = require("cron").CronJob;
  // const job = new cronJob('10 45 00 * * * ', () => {

  const job = new cronJob("30 12 * * *", () => {
    let date = moment().subtract(30, "days").format("MM/DD/YYYY");
    exec(
      'find /home/giang/Phase_3/logs -type f ! -newermt "' +
        date +
        ' 00:00:00" -exec rm -f {} \\;',
      (err, stdout, stderr) => {
        if (err) {
          writeLog("[JOB deleteLog - logs - ERROR]: ", err);
          return;
        }

        writeLog("[JOB deleteLog - logs - STDOUT]: ", stdout);
      }
    );
    exec(
      'find /home/giang/Phase_3/logapp -type f ! -newermt "' +
        date +
        ' 00:00:00" -exec rm -f {} \\;',
      (err, stdout, stderr) => {
        if (err) {
          writeLog("[JOB deleteLog - logapp - ERROR]: ", err);
          return;
        }

        writeLog("[JOB deleteLog - logapp - STDOUT]: ", stdout);
      }
    );
  });

  job.start();
}

function testrun() {
  const cronJob = require("cron").CronJob;
  // const job = new cronJob('10 45 00 * * * ', () => {
  const job = new cronJob("0 */5 * * * *", () => {
    // writeLog("SCHEDULE",'BAT DAU CHAY LAY 10 MA BOM');
    // writeLogMaBom("Check MA BOM THIEU");
    let arr = Object.values(GAS_DATA);
    //04/08/2021 : TRUONGNM sua get ma bom thieu dua vao pump (ma bom hien tai tren cot) so voi currentmaBom (ma bom cuoi cung duoc insert)

    // if(arr)
    // {
    // Helper.getListcotbomThieuMaBom((err, data) => {
    // if(err || !data) return console.log("Khong fillter duoc gia tri");
    // let updates = arr.filter((value, index, array) => {
    // return data.find((val) => val.IdCot == value.id);
    // })

    // for (let a of updates) {
    // if(!a.isDisconnected && a.id && a.com)
    // {
    // writeLogMaBom("Phat hien cot bom thieu ma bom", a.id);
    // getmabom(a.id, a.com, 0);
    // getmabom(a.id, a.com, 1);
    // getmabom(a.id, a.com, 2);
    // getmabom(a.id, a.com, 3);
    // getmabom(a.id, a.com, 4);
    // getmabom(a.id, a.com, 5);
    // getmabom(a.id, a.com, 6);
    // getmabom(a.id, a.com, 7);
    // getmabom(a.id, a.com, 8);
    // getmabom(a.id, a.com, 9);
    // getmabom(a.id, a.com, 10);
    // }
    // }
    // });
    // }

    if (arr) {
      Helper.getListcotbomThieuMaBom((err, data) => {
        if (err || !data) return console.log("Khong fillter duoc gia tri");
        //console.log("Phat hien cot bom thieu ma bom", data);
        // writeLogMaBom("Phat hien cot bom thieu ma bom", data);
        // let updates = arr.filter((value, index, array) => {
        // return data.find((val) => val.IdCot == value.id);
        // })

        for (let a of data) {
          let obj = GAS_DATA[a.IdCot];
          writeLogMaBom("Phat hien cot bom thieu ma bom", a, obj.id);
          if (!obj.isDisconnected && obj.id && obj.com) {
            let somb = obj.pump - a.STTMaBomThieu;
            //06/12/2022 : TRUONGNM sua chi lay ma thieu den 350 (qua gio han luu cua KIT)
            if (somb > 0 && somb < 350) {
              writeLogMaBom(
                "Thieu " +
                  somb +
                  " ma bom cot " +
                  a.IdCot +
                  ", ma hien tai:" +
                  obj.pump +
                  " - lastInsert:" +
                  obj.currentmaBom +
                  " - STTMaBomThieu : " +
                  a.STTMaBomThieu
              );
              for (let cnt = 0; cnt <= somb; cnt++) {
                getmabom(obj.id, obj.com, cnt);
              }
            }
          }
        }
      });
    }

    for (let i of ALL_PUMP) {
      let obj = GAS_DATA[i.id];
      if (
        obj &&
        obj.currentmaBom &&
        obj.currentmaBom > 0 &&
        obj.pump &&
        obj.pump > 0 &&
        obj.status != "hãm" &&
        obj.status != "đang bơm"
      ) {
        let somb = obj.pump - obj.currentmaBom;
        if (somb > 0) {
          //thieu ma bom
          writeLogMaBom(
            "Phat hien thieu ma bom : " +
              somb +
              " ma, cot : " +
              obj.id +
              ", ma hien tai: " +
              obj.pump +
              " - lastInsert:" +
              obj.currentmaBom +
              " - trang thai : " +
              obj.status
          );

          for (let cnt = 0; cnt <= somb; cnt++) {
            getmabom(obj.id, obj.com, cnt);
          }
        }
      }
    }
    //09/08/2021 : TRUONGNM : kiem tra de lay lai ma bom bi sai check sum

    // let thongtinsaichecksum = {
    // thoigian: moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss'),
    // idcot: idcot,
    // pos: pos,
    // pump : GAS_DATA[idcot].pump,
    // currentmaBom : GAS_DATA[idcot].currentmaBom,
    // data : dataInput
    // };

    // try
    // {
    // for (let i of ALL_PUMP) {
    // if(MABOM_DATA[i.id])
    // {
    // let mbsaichecksum =  MABOM_DATA[i.id].shift();
    // writeLogMaBom("mbsaichecksum",i.id,mbsaichecksum);

    // //

    // let somb = i.pump - mbsaichecksum.pump ;
    // if (somb > 0) {
    // //thieu ma bom
    // writeLogMaBom("Chay lai ma bom sai checksum : "+ somb +" ma, cot : "+ i.id +", ma hien tai: " + i.pump + " - mabomsaichecksum:" + mbsaichecksum.pump);

    // for (let cnt = 0; cnt <= somb; cnt++) {
    // getmabom(obj.id, obj.com, cnt);
    // }

    // }

    // }

    // }

    // }catch(e)
    // {
    // writeLog("#error" , e);
    // }

    // for (let i of ALL_PUMP) {
    // //handleMissDataCaBom(i);
    // //handleMissDataMaBom(i);

    // insertLastMaBom(i.id, i.com, 0);
    // insertLastMaBom(i.id, i.com, 1);
    // insertLastMaBom(i.id, i.com, 2);
    // insertLastMaBom(i.id, i.com, 3);
    // insertLastMaBom(i.id, i.com, 4);
    // insertLastMaBom(i.id, i.com, 5);
    // insertLastMaBom(i.id, i.com, 6);
    // insertLastMaBom(i.id, i.com, 7);
    // insertLastMaBom(i.id, i.com, 8);
    // insertLastMaBom(i.id, i.com, 9);
    // insertLastMaBom(i.id, i.com, 10);
    // }
    //writeLog("SCHEDULE",'KETHUC CHAY LAY 10 MA BOM');
    //console.log("SCHEDULE",'KETHUC CHAY LAY 10 MA BOM');
  });

  job.start();
}

setInterval(() => {
  for (let i of ALL_PUMP) {
    // Helper.selectDsChotCaChuaChotNgay(i.id, (err, data) => {
    // let obj = GAS_DATA[i.id];
    // err && writeLog(err);
    // if (obj) {
    // obj.tienchuachotngay = err ? 0 : data[0].giatien;
    // obj.litchuachotngay = err ? 0 : data[0].lit;
    // obj.timeUpdateChotNgay = new Date();
    // }
    // });
    let obj = GAS_DATA[i.id];
    if (obj) {
      obj.tienchuachotngay = 0;
      obj.litchuachotngay = 0;
      obj.timeUpdateChotNgay = new Date();
    }
  }
}, 15000);

// MANHLD Lấy thời gian timeout dựa trên số lần disconnect
function getTimeOut(count) {
  if (!timeOutArray || timeOutArray.length == 0) return 100;
  if (count < 1) return timeOutArray[0];

  return count <= timeOutArray.length
    ? timeOutArray[count - 1]
    : timeOutArray[timeOutArray.length - 1];
}

// MANHLD Hàm xử lý chung lúc lệnh bị timeout
function handleCMDTimeout({ id }, err, cb) {
  let obj = GAS_DATA[id];
  if (!obj) {
    obj = GAS_DATA[i.id] = { timeOut: 0 };
  }
  if (!obj.timeOut) {
    obj.timeOut = 1;
  } else obj.timeOut += 1;
  if (!obj.isDisconnected && obj.timeOut > 10) {
    obj.timeStartDisconnect = new Date();
    obj.isDisconnected = true;
  }
  let timeOutInMilisecond = getTimeOut(obj.timeOut);
  setTimeout(() => {
    if (cb) cb();
  }, timeOutInMilisecond);
  writeLogTimeOut(`Timeout , cot-${id}, ${obj.timeOut}s`);
}

function getQuickUpdate(i) {
  let arr = [CMD.STX, 0, i.id, CMD.cmdQUP];
  GAS.sendCommand(arr, i.com, i.id, "getQuickUpdate", (err, data) => {
    //writeLogReceivedFromKIT("getFullUpdate",arr,err,data);
    if (err) {
      return handleCMDTimeout(i, err, () => getQuickUpdate(i));
    }

    let statusID = xuLyDuLieuGetQuickUpdate(i, err, data);
    //console.log("Quick Update: ", StatusBom[statusID]);
    let obj = GAS_DATA[i.id];
    if (!obj) {
      obj = GAS_DATA[i.id] = {};
    }
    if (statusID === 0x20 && !obj.flagGetMaBom) {
      insertLastMaBom(i.id, i.com, 0);
      insertLastMaBom(i.id, i.com, 1);
      insertLastMaBom(i.id, i.com, 2);
    } else if (statusID === 0x22 || statusID === 0x23) {
      if (obj.flagGetMaBom != false) {
        obj.flagGetMaBom = false;
        writeLogMaBom(
          "#Phathienmabommoi getQuickUpdate idcot : " +
            i.id +
            " - statusID " +
            statusID +
            " - status : " +
            obj.status +
            " - current pump :  " +
            obj.pump +
            " - current mabom :  " +
            obj.currentmaBom
        );
      }
    }

    if (statusID == 0x22 || statusID == 0x23 || statusID == 0x20) {
      setTimeout(() => {
        getQuickUpdate(i);
      }, 120);
    } else {
      setTimeout(() => {
        getNewRfid(i);
      }, 120);
    }
  });
}

function getNewRfid(i) {
  //console.log("getNewRfid");
  let arr = [CMD.STX, 0, i.id, CMD.cmdINF];
  GAS.sendCommand(arr, i.com, i.id, "getNewRfid", (err, data) => {
    //writeLogReceivedFromKIT("getFullUpdate",arr,err,data);
    if (err) {
      console.log("Error getNewRFID", err);
      return handleCMDTimeout(i, err, () => getNewRfid(i));
    }

    let statusID = xuLyDuLieuNewRfid(i, err, data);
    //console.log("New RFID: ", StatusBom[statusID]);
    let obj = GAS_DATA[i.id];
    if (!obj) {
      obj = GAS_DATA[i.id] = {};
    }

    // 0x22: "đang bơm",0x23: "hãm"
    if (!(statusID === 0x22 || statusID === 0x23) && !obj.flagGetMaBom) {
      //insertLastMaBom(i.id, i.com, 0);
      //insertLastMaBom(i.id, i.com, 1);
      //insertLastMaBom(i.id, i.com, 2);
    }

    if (statusID == 0x22 || statusID == 0x23 || statusID == 0x20) {
      setTimeout(() => {
        getQuickUpdate(i);
      }, 120);
    } else {
      setTimeout(() => {
        getNewRfid(i);
      }, 500);
    }
  });
}

function xuLyDuLieuNewRfid(i, err, data) {
  if (err) {
    return;
  }
  if (GAS_DATA[i.id] && GAS_DATA[i.id].isDisconnected) {
    GAS_DATA[i.id].isDisconnected = false;
    writeLog("#knl Ket noi lai ", i.id);
  }
  let obj = GAS_DATA[i.id];
  if (!GAS_DATA[i.id]) {
    obj = GAS_DATA[i.id] = {};
  }
  obj.tienOld = obj.tien;
  obj["id"] = i.id;
  obj["com"] = i.com;
  let statusID = bytesToInt(getSubArray(data, 4, 1));
  obj["status"] = StatusBom[statusID] || "";
  if (statusID == 16 && obj["statusID"] != 16) {
    insertLastMaBom(i.id, i.com, 0);
  }
  if (statusID == 0x32 || statusID == 0x33) {
    GAS_DATA[i.id].flagGetCaBom = false;
  }
  obj.timeOut = 0;
  obj["statusID"] = statusID;
  obj["pump"] = bytesToInt(getSubArray(data, 5, 4));
  obj["lit"] = bytesToInt(getSubArray(data, 9, 4)) / 1000.0;
  const don_gia = bytesToInt(getSubArray(data, 13, 4));
  obj["tien"] = bytesToInt(getSubArray(data, 17, 4));
  obj["ca_Lit"] = bytesToInt(getSubArray(data, 21, 4));
  obj["ca_mLit"] = bytesToInt(getSubArray(data, 25, 2));
  obj["tongsolitdenhientai"] = bytesToInt(getSubArray(data, 27, 4));
  obj["totalcare"] = bytesToInt(getSubArray(data, 31, 2));
  obj["macabom"] = bytesToInt(getSubArray(data, 33, 2));
  try {
    //MANHLD them phan cap nhat lai metro 30/05/2024
    let idloainhienlieu = bytesToInt(getSubArray(data, 35, 1));
    GAS_DATA[i.id].metro = CONFIG.getMetroName(idloainhienlieu);
    GAS_DATA[i.id].metroId = idloainhienlieu;
  } catch (e) {}
  let Flag = bytesToInt(getSubArray(data, 45, 1));
  obj["flag"] = Flag | 0x00;
  obj["thoigianUpdateCuoi"] = moment(Date.now()).format("DD-MM-YYYY HH:mm:ss");
  let id_nhanvien = bytesToInt(getSubArray(data, 36, 4));
  if (id_nhanvien) obj["IDNhanvien"] = id_nhanvien;
  let id_khachhang = bytesToInt(getSubArray(data, 40, 4));
  let isCaBomChange =
    !GAS_DATA[i.id].CaBomMoiNhat ||
    (obj["macabom"] && GAS_DATA[i.id].CaBomMoiNhat.idca != obj["macabom"]);
  if (isCaBomChange) {
    writeLogCaBom("Phat hien ca bom moi goi ham get3CaBomGanNhat");
    GAS_DATA[i.id].CaBomMoiNhat = {
      idca: obj["macabom"],
    };
    obj.isGiaBomChange = false; //ManhLD 23/08/2024 fix doi gia
    get3CaBomGanNhat(i.id, i.com, 0); // Phát hiện có ca bơm mới, gọi hàm lấy 3 ca bơm đã chốt gần nhất
  }

  //console.log("New RFID don gia: ", don_gia);
  ///ManhLD them phan cap nhat gia tren server 17/08/2024
  if (!obj["dongia"] || don_gia != obj["dongia"]) {
    console.log("Phat hien gia ban thay doi", i.id, obj["dongia"], don_gia);
    writeLogCaBom("Phat hien gia ban thay doi", i.id, obj["dongia"], don_gia);
    setDonGiaHienTai(i.id, don_gia);
    obj.isGiaBomChange = true; //ManhLD 23/08/2024 fix doi gia
  }

  if (
    !GAS_DATA[i.id].CaBomMoiNhat.gia &&
    obj["lit"] &&
    obj["lit"] > 0 &&
    obj["tien"] &&
    obj["tien"] > 0 &&
    Math.abs(obj["lit"] * don_gia - obj["tien"]) < 80
  ) {
    ///ManhLD them phan check doi gia 30/05/2024
    //Nếu phát hiện giá khác với trước đó và số lít, số tiền đã bơm > 0 thì chốt giá của ca và tiến hành cập nhật giá
    if (obj.isGiaBomChange) capNhatGiaBan(i.id, don_gia, obj["macabom"]); //ManhLD 23/08/2024 fix doi gia
    GAS_DATA[i.id].CaBomMoiNhat.gia = don_gia; // Chốt giá của ca
  }

  if (id_khachhang) {
    obj["IDKhachhang"] = id_khachhang;
    Helper.getHanmuc(id_khachhang, i.id, (err, data) => {
      if (err) {
        writeLogHanmuc(err);
      } else {
        if (data && data.length) {
          data = data[0];
          if (!data.IsBom || data.HanMucTaiXe <= 0) {
            logoff(i, id_khachhang, (data) => {
              data = Buffer.from(data).toString("hex");
              writeLogHanmuc(
                i.id,
                id_khachhang,
                statusID,
                "Khach hang khong duoc bom.",
                data
              );
            });
          } else {
            let hanmuc =
              data.HanMucTaiXe <= data.HanMucKhachHang
                ? data.HanMucTaiXe
                : data.HanMucKhachHang;
            if (!obj["hanmuc"] || obj["hanmuc"] != hanmuc) {
              obj["hanmuc"] = hanmuc;
              if (data.ID_LoaiHanMuc == 1) {
                if (hanmuc >= 0.25 * data.GiaBan) {
                  BomtheoHanmuc(
                    i.id,
                    i.com,
                    0,
                    hanmuc,
                    obj["IDNhanvien"],
                    id_khachhang,
                    (data) => {
                      data = Buffer.from(data).toString("hex");
                      writeLogHanmuc(
                        i.id,
                        id_khachhang,
                        "Han muc bom theo gia tien.",
                        hanmuc,
                        data
                      );
                    }
                  );
                } else {
                  logoff(i, id_khachhang, (data) => {
                    data = Buffer.from(data).toString("hex");
                    writeLogHanmuc(
                      i.id,
                      id_khachhang,
                      statusID,
                      "Khach hang khong duoc bom.",
                      data
                    );
                  });
                }
              } else if (data.ID_LoaiHanMuc == 2) {
                obj["Loaihanmuc"] = 2;
                var hanmuc_mLit = Math.floor((hanmuc * 1000) / data.GiaBan);
                if (hanmuc_mLit >= 250) {
                  BomtheoHanmuc(
                    i.id,
                    i.com,
                    1,
                    hanmuc_mLit,
                    obj["IDNhanvien"],
                    id_khachhang,
                    (data) => {
                      data = Buffer.from(data).toString("hex");
                      writeLogHanmuc(
                        i.id,
                        id_khachhang,
                        "Han muc bom theo lit.",
                        hanmuc_mLit,
                        data
                      );
                    }
                  );
                } else {
                  logoff(i, id_khachhang, (data) => {
                    data = Buffer.from(data).toString("hex");
                    writeLogHanmuc(
                      i.id,
                      id_khachhang,
                      statusID,
                      "Khach hang khong duoc bom.",
                      data
                    );
                  });
                }
              }
            }
          }
        }
      }
    });
    // if(!obj["IDKhachhang"] || obj["IDKhachhang"] != id_khachhang)
    // {
    //     obj["IDKhachhang"] = id_khachhang;

    // }
  } else {
    obj["IDKhachhang"] = null;
    obj["hanmuc"] = null;
  }

  //obj["tongsolitdenhientai"] = bytesToInt(getSubArray(data, 27, 4)) + (obj["totalcare"] / 1000);

  /*
	//3.2.4 : TRUONGNM fix:bo ham getlastcabom trong xu ly xuLyDuLieuNewRfid
	if (statusID !== 0x22 && statusID !== 0x23 && !obj.flagGetCaBom) {
        getLastCaBom(i.id, i.com, 0);
        obj.flagGetCaBom = true;
    } else {
        obj.flagGetCaBom = false;
    }
	
	
	//0x10: "sẵn sàng",0x40: "log off",
    if (!obj.isHandleMaBom && (obj['statusID'] === 0x10 || obj['statusID'] === 0x40)) {
        //xu ly ma bom, khi get full update xong thi check trang thai cua kit de lay ma bom roi tru dan ve
        //console.log("obj.timeStartDisconnect", obj)
        
		//TRUONGNM : bo lay ma bom
		//obj.isHandleMaBom = true;
        //handleMissDataCaBom(i);
        //handleMissDataMaBom(i);
    }
	*/
  return statusID;
}

function xuLyDuLieuGetQuickUpdate(i, err, data) {
  if (err) {
    return;
  }
  if (GAS_DATA[i.id] && GAS_DATA[i.id].isDisconnected) {
    GAS_DATA[i.id].isDisconnected = false;
    writeLog("#knl Ket noi lai ", i.id);
  }
  let obj = GAS_DATA[i.id];
  if (!GAS_DATA[i.id]) {
    obj = GAS_DATA[i.id] = {};
  }
  obj.tienOld = obj.tien;
  obj["id"] = i.id;
  obj["com"] = i.com;
  let statusID = bytesToInt(getSubArray(data, 4, 1));
  obj["status"] = StatusBom[statusID] || "";
  if (statusID == 16 && obj["statusID"] != 16) {
    insertLastMaBom(i.id, i.com, 0);
  }
  if (statusID == 0x32 || statusID == 0x33) {
    GAS_DATA[i.id].flagGetCaBom = false;
  }
  obj.timeOut = 0;
  obj["IDKhachhang"] = null;
  obj["statusID"] = statusID;
  obj["lit"] = bytesToInt(getSubArray(data, 5, 4)) / 1000.0;
  obj["tien"] = bytesToInt(getSubArray(data, 9, 4));
  obj["thoigianUpdateCuoi"] = moment(Date.now()).format("DD-MM-YYYY HH:mm:ss");
  //obj["tongsolitdenhientai"] = bytesToInt(getSubArray(data, 27, 4)) + (obj["totalcare"] / 1000);
  if (statusID !== 0x22 && statusID !== 0x23 && !obj.flagGetCaBom) {
    get3CaBomGanNhat(i.id, i.com); //ManhLD them phan lay cac ca bom gan nhat 21/05/2024
    obj.flagGetCaBom = true;
  } else {
    obj.flagGetCaBom = false;
  }
  //0x10: "sẵn sàng",0x40: "log off",
  if (
    !obj.isHandleMaBom &&
    (obj["statusID"] === 0x10 || obj["statusID"] === 0x40)
  ) {
    //xu ly ma bom, khi get full update xong thi check trang thai cua kit de lay ma bom roi tru dan ve
    //console.log("obj.timeStartDisconnect", obj)
    //TRUONGNM : bo lay ma bom
    //obj.isHandleMaBom = true;
    //handleMissDataCaBom(i);
    // handleMissDataMaBom(i);
  }
  return statusID;
}

function logoff(i, id_khachhang, cb) {
  let arr = [CMD.STX, 0, i.id, CMD.cmdLOF];
  GAS.sendCommand(arr, i.com, i.id, "logoff", (err, data) => {
    //writeLogReceivedFromKIT("getFullUpdate",arr,err,data);
    if (err) {
      return handleCMDTimeout(i, err, () =>
        logoff(i, id_khachhang, (data) => {
          data = Buffer.from(data).toString("hex");
          writeLogHanmuc(
            i.id,
            id_khachhang,
            "Khach hang khong duoc bom.",
            data
          );
        })
      );
    }

    cb(data);
  });
}

function BomtheoHanmuc(
  id,
  com,
  loai_hanmuc,
  hanmuc,
  id_nhanvien,
  id_khachhang,
  callback
) {
  let lenhbom = {
    thoigianbatdau: moment.parseZone(new Date()).format("DD/MM/YYYY HH:mm:ss"),
    STX: CMD.STX,
    cmdPUM: CMD.cmdPUM,
    id: id,
    com: com,
    thoigianketthuc: null,
    msg: "Đang xử lý!",
  };

  GAS_DATA[id].lenhbom_gannhat = lenhbom;
  eneableWrite(id, com, (err, data) => {
    const resJson = { status: false, msg: "Xử lý thành công!" };
    if (err) {
      resJson.status = false;
      resJson.msg = `Timeout trong quá trình eneableWrite id: ${id} com: ${com}`;
      writeLog(
        "error bom theo han muc => phan hoi tu kit (#CMD.cmdACK)",
        id,
        com,
        err,
        resJson.msg
      );

      lenhbom.msg = resJson.msg;
      lenhbom.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      GAS_DATA[id].lenhbom_gannhat = lenhbom;
    } else if (data[3] === CMD.cmdACK) {
      writeLog("gui hanmuc den kit", id, com);
      GAS.sendCommand(
        [
          CMD.STX,
          0,
          id,
          CMD.cmdPUM,
          ...numberToByteArray(loai_hanmuc, 2),
          0x04,
          ...numberToByteArray(hanmuc, 4),
          ...numberToByteArray(id_nhanvien, 4),
          ...numberToByteArray(id_khachhang, 4),
          ...numberToByteArray(0, 4),
        ],
        com,
        id,
        "hanmuc",
        (err, dt) => {
          //writeLogReceivedFromKIT("chotca",[CMD.STX, 0, id, CMD.cmdCLS],id,com,err,data);

          writeLog("du lieu hanmuc", dt, err);
          if (dt && dt[3] === CMD.cmdACK) {
            resJson.status = true;

            resJson.msg = "Xử lý thành công!";
            lenhbom.msg = resJson.msg;
            lenhbom.thoigianketthuc = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
            writeLog("success send hanmuc => ", id, com);
          } else {
            resJson.msg = `Device bận trong quá trình cmdPUM, mã lỗi 0x${
              dt ? dt[4] : "cc"
            },${err ? err : ""}`;
            writeLog(
              "error bom theo han muc => phan hoi tu kit (#CMD.cmdACK)",
              id,
              com,
              data,
              resJson.msg
            );
            lenhbom.msg = resJson.msg;
            lenhbom.thoigianketthuc = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
          }
          GAS_DATA[id].lenhbom_gannhat = lenhbom;
          if (callback) {
            callback(dt);
          }
        }
      );
    } else {
      console.log("Write DEVICE BẬN.");
      resJson.status = false;
      resJson.msg = `Device bận trong quá trình cmdWEN and PUM, mã lỗi 0x${
        data ? data[4] : "cc"
      }`;

      lenhbom.msg = resJson.msg;
      lenhbom.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      GAS_DATA[id].lenhbom_gannhat = lenhbom;

      writeLog(
        "error bom=> phan hoi tu kit (#CMD.cmdACK)",
        id,
        com,
        data,
        resJson.msg
      );
    }
  });
}

function getFullUpdate(i) {
  let arr = [CMD.STX, 0, i.id, CMD.cmdFUP];
  writeLog("GETFULLUPDATE", i.id);
  GAS.sendCommand(arr, i.com, 0, "getFullUpdate", (err, data) => {
    //writeLogReceivedFromKIT("getFullUpdate",arr,err,data);
    if (err) {
      return handleCMDTimeout(i, err, () => getFullUpdate(i));
    }
    let statusID = xuLyDuLieuGetFullUpdate(i, err, data);
    if (statusID === 0x22 || statusID === 0x23) {
      setTimeout(() => {
        getFullUpdate(i);
      }, 120);
    } else {
      setTimeout(() => {
        getTrangThaiCotBom(i);
      }, 120);
    }
  });
}

function getTrangThaiCotBom(i) {
  let arr = [CMD.STX, 0, i.id, CMD.cmdSTA];
  GAS.sendCommand(arr, i.com, i.id, "getTrangThaiCotBom", (err, data) => {
    //writeLogReceivedFromKIT("getTrangThaiCotBom",arr,err,data);
    if (data) {
      let obj = GAS_DATA[i.id];
      if (!obj) {
        obj = GAS_DATA[i.id] = {};
      }
      obj["id"] = i.id;
      obj.timeOut = 0;
      obj.timeGetTrangThai = new Date();
      if (obj.isDisconnected) {
        obj.isDisconnected = false;
        if (obj.timeStartDisconnect) {
          let dateDiff =
            -obj.timeStartDisconnect.getTime() + new Date().getTime();
          if (dateDiff > 10000) {
            eventEmitter.emit("reconnect", "hi");
            obj.isHandleMaBom = false;
          }
          // laays lai ma bom ca bom khi mat ket noi qua 1ph
        }
      }

      obj["com"] = i.com;
      let statusID = bytesToInt(getSubArray(data, 4, 1));
      obj["status"] = StatusBom[statusID] || "";
      obj.statusID = statusID;

      // 0x22: "đang bơm",0x23: "hãm"
      if (!(statusID === 0x22 || statusID === 0x23) && !obj.flagGetMaBom) {
        insertLastMaBom(i.id, i.com, 0);
        insertLastMaBom(i.id, i.com, 1);
        insertLastMaBom(i.id, i.com, 2);
      }
      //  0x32: "menu",    0x33: "Lock k bơm",
      if (statusID === 0x32 || statusID === 0x33) {
        obj.flagGetFullUpdate = true;
        //todo update
        getFullUpdate(i);
      } else if (statusID === 0x22 || statusID === 0x23) {
        //đang bơm lấy liên tục getFullUpdate
        if (obj.flagGetMaBom != false) {
          //console.log("#Phathienmabommoi", i.id);
          writeLogMaBom(
            "#Phathienmabommoi getTrangThaiCotBom idcot : " +
              i.id +
              " - statusID " +
              statusID +
              " - status : " +
              obj.status +
              " - current pump :  " +
              obj.pump +
              " - current mabom :  " +
              obj.currentmaBom
          );
          obj.flagGetMaBom = false;
        }
        getFullUpdate(i);
      } else {
        if (obj.flagGetFullUpdate) {
          obj.flagGetFullUpdate = false;
          getFullUpdate(i);
        } else {
          setTimeout(() => {
            getTrangThaiCotBom(i);
          }, 1500);
        }
      }
      //0x10: "sẵn sàng",0x40: "log off",
      if (
        !obj.isHandleMaBom &&
        (obj["statusID"] === 0x10 || obj["statusID"] === 0x40)
      ) {
        //writeLog("obj.timeStartDisconnect")
        // obj.isHandleMaBom = true;
        //handleMissDataCaBom(i);
        //handleMissDataMaBom(i);
      }
    } else if (err) {
      handleCMDTimeout(i, err, () => {
        writeLogCaBom(
          "matketnoi:" + i.id,
          err,
          GAS_DATA[i.id],
          "getTrangThaiCotBom"
        );
        getTrangThaiCotBom(i);
      });
    }
  });
}

eventEmitter.on("CabomMoi", (idcot) => {
  let cotbom = ALL_PUMP.find((i) => i.id === idcot);
  if (cotbom) {
    get3CaBomGanNhat(cotbom.id, cotbom.com); //ManhLD them phan lay cac ca bom gan nhat 21/05/2024
    getFullUpdate(cotbom);
  }
});

for (let i of ALL_PUMP) {
  getLoaiNhienLieu(i);
}

function capNhatGiaBan(idCot, donGia, idca = 0) {
  Helper.capNhatGiaBan(idCot, donGia, idca)
    .then((result) => {
      writeLog("CAPNHATGIABAN SUCCESS", result);
    })
    .catch((err) => writeLog("CAPNHATGIABAN ERROR", err));
}

function xuLyDuLieuGetFullUpdate(i, err, data) {
  if (err) {
    return;
  }
  if (GAS_DATA[i.id] && GAS_DATA[i.id].isDisconnected) {
    GAS_DATA[i.id].isDisconnected = false;
    writeLog("#knl Ket noi lai ", i.id);
  }
  let obj = GAS_DATA[i.id];
  if (!GAS_DATA[i.id]) {
    obj = GAS_DATA[i.id] = {};
  }
  obj.tienOld = obj.tien;
  obj["id"] = i.id;
  obj["com"] = i.com;
  let statusID = bytesToInt(getSubArray(data, 4, 1));
  obj["status"] = StatusBom[statusID] || "";

  if (statusID == 16 && obj["statusID"] != 16) {
    insertLastMaBom(i.id, i.com, 0);
  }

  if (statusID == 0x32 || statusID == 0x33) {
    GAS_DATA[i.id].flagGetCaBom = false;
  }
  obj.timeOut = 0;
  obj["statusID"] = statusID;
  obj["pump"] = bytesToInt(getSubArray(data, 5, 4));
  obj["lit"] = bytesToInt(getSubArray(data, 9, 4)) / 1000.0;
  const gia = bytesToInt(getSubArray(data, 13, 4));
  obj["tien"] = bytesToInt(getSubArray(data, 17, 4));
  obj["ca_Lit"] = bytesToInt(getSubArray(data, 21, 4));
  obj["ca_mLit"] = bytesToInt(getSubArray(data, 25, 2));
  obj["totalcare"] = bytesToInt(getSubArray(data, 31, 2));
  obj["thoigianUpdateCuoi"] = moment(Date.now()).format("DD-MM-YYYY HH:mm:ss");
  //obj["tongsolitdenhientai"] = bytesToInt(getSubArray(data, 27, 4)) + (obj["totalcare"] / 1000);
  obj["tongsolitdenhientai"] = bytesToInt(getSubArray(data, 27, 4));
  if (statusID !== 0x22 && statusID !== 0x23 && !obj.flagGetCaBom) {
    get3CaBomGanNhat(i.id, i.com, 0);
    obj.flagGetCaBom = true;
  } else {
    obj.flagGetCaBom = false;
  }
  //0x10: "sẵn sàng",0x40: "log off",
  if (
    !obj.isHandleMaBom &&
    (obj["statusID"] === 0x10 || obj["statusID"] === 0x40)
  ) {
    //xu ly ma bom, khi get full update xong thi check trang thai cua kit de lay ma bom roi tru dan ve
    //console.log("obj.timeStartDisconnect", obj)
    //TRUONGNM : bo lay ma bom
    //obj.isHandleMaBom = true;
    //handleMissDataCaBom(i);
    //handleMissDataMaBom(i);
  }
  return statusID;
}

function getLoaiNhienLieu(i) {
  GAS.sendCommand(
    [
      CMD.STX,
      0,
      i.id,
      CMD.cmdRD,
      ...numberToByteArray(ADDR.Petro.bytecode),
      ADDR.Petro.nbyte,
    ],
    i.com,
    0,
    "getLoaiNhienLieu",
    (err, data) => {
      //writeLogReceivedFromKIT("getLoaiNhienLieu",[CMD.STX, 0, i.id, CMD.cmdRD, ...numberToByteArray(ADDR.Petro.bytecode), ADDR.Petro.nbyte], i.com,err,data);
      if (err) {
        // handleCMDTimeout(i, err, () => {
        //   getLoaiNhienLieu(i);
        // });

        return writeLog(err);
      }
      if (data.length === 10) {
        if (!GAS_DATA[i.id]) {
          GAS_DATA[i.id] = {
            ...i,
            metro: CONFIG.getMetroName(data[7]),
            metroId: data[7],
            timeOut: 0,
            isDisconnected: false,
          };
        } else {
          GAS_DATA[i.id].metro = CONFIG.getMetroName(data[7]);
          GAS_DATA[i.id].metroId = data[7];
        }
        getMaCaNow(i);
        //writeLog(GAS_DATA[i.id]);
      } else {
        writeLog(
          "Lỗi lấy loại nhiên liệu ",
          data.toString("hex").match(/../g).join(" ")
        );
        setTimeout(() => {
          getLoaiNhienLieu(i);
        }, 1000);
      }
    }
  );
}

function addCaBomDescending(array, cabom) {
  const index = array.findIndex((el) => el.thoigian < cabom.thoigian);
  if (index === -1) {
    array.push(cabom);
  } else {
    array.splice(index, 0, cabom);
  }
  console.log("addCaBomDescending", array);
}

//ManhLD them ham lay ca bom gan nhat
function get3CaBomGanNhat(idcot, com, pos = 0) {
  //writeLogCaBom("getLastCaBom", idcot,com,pos)
  if (pos > 2) return;
  console.error("get3CaBomGanNhat", idcot, pos);
  try {
    GAS.sendCommand(
      [CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32],
      com,
      pos,
      "getCaBomGanNhat",
      (err, data) => {
        console.error("Da vao Ca Bom Gan Nhat ", idcot, pos);
        if (data && data[3] !== 78) {
          let obj = xulydulieuCaBom(data, idcot, pos);
          if (obj) {
            obj.idct = CONFIG.getIDCT();
            if (CONFIG.getIDCT() > 0) {
              writeLogCaBom("Success Get3CaBomGanNhat ", idcot, pos, obj);
              if (!GAS_DATA[idcot].CaBomCu) GAS_DATA[idcot].CaBomCu = [];
              let caBomTrung = GAS_DATA[idcot].CaBomCu.find(
                (e) => e.idca === obj.idca
              );
              try {
                if (!caBomTrung) {
                  // Nếu không có ca bơm bị trùng thì thêm vào mảng
                  addCaBomDescending(GAS_DATA[idcot].CaBomCu, obj);
                } else if (caBomTrung.thoigian < obj.thoigian) {
                  // Nếu có ca bơm bị trùng và ca bơm mới lấy được (obj) có thời gian lớn hơn thì thay thế
                  GAS_DATA[idcot].CaBomCu = GAS_DATA[idcot].CaBomCu.filter(
                    (e) => e.idca !== obj.idca
                  );
                  addCaBomDescending(GAS_DATA[idcot].CaBomCu, obj);
                }
              } catch (e) {
                console.error(e);
              }

              Helper.insertCaBom(obj, (err, data) => {
                //writeLogCaBom("Success insert Cabom", obj, err, data);
              });
              setTimeout(() => {
                get3CaBomGanNhat(idcot, com, pos + 1);
              }, 100);
            } else {
              writeCaBomChuaGui(idcot, obj.idca, obj);
              writeLogCaBom(
                "#CaBomMoiEvent",
                "Khong insert do chua lay duoc cau hinh IDCT ",
                pos,
                obj
              );
              setTimeout(() => {
                get3CaBomGanNhat(idcot, com, pos);
              }, 100);
            }
          } else {
            writeLogCaBom(
              `getCaBomGanNhat getThatBai,xu ly data loi ${data}: cot-`,
              idcot,
              2,
              obj
            );
            setTimeout(() => {
              get3CaBomGanNhat(idcot, com, pos);
            }, 100);
          }
        } else {
          console.log("Get Ca Bom Error: ", err);
          writeLogCaBom(
            "getCaBomGanNhat getThatBai cot-",
            idcot,
            3,
            data ? data : err
          );
          setTimeout(() => {
            get3CaBomGanNhat(idcot, com, pos);
          }, 500);
        }
      }
    );
  } catch (err) {
    console.error(err);
  }
  console.error("get3CaBomGanNhat2", idcot, pos);
}

function getLastCaBom(idcot, com, pos = 0) {
  console.log("GetLastCaBom ", com);
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32],
    com,
    pos,
    "getLastCaBom",
    (err, data) => {
      //writeLogReceivedFromKIT("getLastCaBom",[CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32], com,pos,err,data);

      if (data && data[3] !== 78) {
        let obj = xulydulieuCaBom(data, idcot, 0);

        if (obj) {
          // writeLogCaBom("getLastCaBom getThanhCong: cot-", idcot, 1, obj);
          obj.idct = CONFIG.getIDCT();
          if (CONFIG.getIDCT() > 0) {
            //07/05/20202 : TRUONGNM : Them ca bom moi nhat vao danh sach cot
            if (pos == 0) {
              if (!GAS_DATA[idcot].CaBomCu) GAS_DATA[idcot].CaBomCu = [];
              let caBomTrung = GAS_DATA[idcot].CaBomCu.find(
                (e) => e.idca === obj.idca
              );
              try {
                if (!caBomTrung) {
                  // Nếu không có ca bơm bị trùng thì thêm vào mảng
                  GAS_DATA[idcot].CaBomCu.unshift(obj);
                } else if (caBomTrung.thoigian < obj.thoigian) {
                  // Nếu có ca bơm bị trùng và ca bơm mới lấy được (obj) có thời gian lớn hơn thì thay thế
                  GAS_DATA[idcot].CaBomCu = GAS_DATA[idcot].CaBomCu.filter(
                    (e) => e.idca !== obj.idca
                  );
                  GAS_DATA[idcot].CaBomCu.unshift(obj);
                }
              } catch (e) {
                console.error(e);
              }
            }
            Helper.insertCaBom(obj, (err, data) => {
              console.log("#CaBomMoiEvent", obj);
              writeLogCaBom(
                "#CaBomMoiEvent",
                "insert lastCabom ",
                pos,
                obj,
                data
              );
            });
          } else {
            writeCaBomChuaGui(idcot, obj.idca, obj);
            writeLogCaBom(
              "#CaBomMoiEvent",
              "Khong insert do chua lay duoc cau hinh IDCT ",
              pos,
              obj
            );
          }
        } else {
          writeLogCaBom(
            `getLastCaBom getThatBai,xu ly data loi ${data}: cot-`,
            idcot,
            2,
            obj
          );
          setTimeout(() => {
            getLastCaBom(idcot, com, 0);
          }, 1000);
        }
      } else {
        writeLogCaBom(
          "getLastCaBom getThatBai cot-",
          idcot,
          3,
          data ? data : err
        );
        // setTimeout(() => {
        // getLastCaBom(idcot, com, 0)
        // }, 1000);
      }
    }
  );
}

function getMaCaNow(i) {
  GAS.sendCommand(
    [
      CMD.STX,
      0,
      i.id,
      CMD.cmdRD,
      ...numberToByteArray(ADDR.Shift_code.bytecode),
      ADDR.Shift_code.nbyte,
    ],
    i.com,
    ADDR.Shift_code.bytecode,
    "getMaCaNow",
    (err, data) => {
      //writeLogReceivedFromKIT("getMaCaNow",[CMD.STX, 0, i.id, CMD.cmdRD, ...numberToByteArray(ADDR.Shift_code.bytecode), ADDR.Shift_code.nbyte], i.com,err,data);

      if (err) {
        writeLogMaBom(err);
        setTimeout(() => {
          getMaCaNow(i);
        }, 1000);
        return;
      }
      if (data.length == 11) {
        //writeLogMaBom(data, ' hehe')
        GAS_DATA[i.id] = {
          ...GAS_DATA[i.id],
          caID: bytesToInt(getSubArray(data, 7, 2)),
        };
      } else {
        setTimeout(() => {
          writeLogMaBom(i);
        }, 1000);
        console.warn("Device ban", data);
      }
    }
  );
}

function getSubArray(arr, start, length) {
  return arr.filter((item, i) => i >= start && i <= start + length - 1);
}

function numberToByteArray(/*long*/ number, arrLeng = 2) {
  // we want to represent the input as a 8-bytes array
  let byteArray = new Array(arrLeng);
  for (var index = 0; index < byteArray.length; index++) {
    var byte = number & 0xff;
    byteArray[index] = byte;
    number = (number - byte) / 256;
  }
  return byteArray;
}

function bytesToInt(byteArray) {
  let value = 0;
  for (let i = byteArray.length - 1; i >= 0; i--) {
    value = value * 256 + byteArray[i];
  }
  return value;
}

function getGasData(type = 0) {
  //0 la arr, != la obj
  if (type !== 0) {
    return GAS_DATA;
  }
  return Object.values(GAS_DATA);
}


function isTrustData(arr) {
    let total = arr.reduce((sum, i) => sum += i, 0);
    return (total & 0xff) === 0;
}
/*
function isTrustData(arr) {
  let total = arr.reduce((sum, i) => (sum += i), 0);
  let cks = (0 - total) & 0xff;
  let upper = cks & 0xf0;
  let lower = cks & 0x0f;
  let upperok =
    (upper == 0x80) | (upper == 0x40) | (upper == 0x10) | (upper == 0x00);
  let lowerok =
    (lower == 0x04) |
    (lower == 0x02) |
    (lower == 0x01) |
    (lower == 0x00) |
    (lower == 0x06) |
    (lower == 0x05);
  let ret = upperok === 1 && lowerok === 1;
  return ret;
}
*/
function handleMissDataMaBom(pump) {
  writeLog("##bat dau lay ma bom reconnect idcot : " + pump.id);
  handleMaBom(pump.id, pump.com, 0);
}

function handleMissDataCaBom(pump) {
  writeLog("##bat dau lay ca bom reconnect idcot : " + pump.id);
  handleCaBom(pump.id, pump.com);
}

function insertLastMaBom(idcot, com, pos = 0) {
  //writeLogMaBom("Bat dau lay ma bom cot ", idcot);
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDP, ...numberToByteArray(pos), 32],
    com,
    pos,
    "insertLastMaBom",
    (err, data) => {
      //writeLogReceivedFromKIT("insertLastMaBom",[CMD.STX, 0, idcot, CMD.cmdRDP, ...numberToByteArray(pos), 32], com,err,data);

      if (err) {
        writeLogMaBom(
          "#mabommoi",
          "insertLastMaBom=>error",
          idcot,
          com,
          pos,
          err
        );
        //04.08.2021 : TRUONGNM bo doan de xem co bi lap cho nay khong: return insertLastMaBom(idcot, com, pos);
        return; // insertLastMaBom(idcot, com, pos);
      }
      let mabom = xuLyDuLieuMaBom(idcot, data, pos);
      if (mabom) {
        GAS_DATA[idcot].flagGetMaBom = true;

        if (pos == 0) {
          //06/08/2021 : TRUONGNM : check thieu ma bom bo sung
          if (mabom.pump - GAS_DATA[idcot].currentmaBom > 1) {
            writeLogMaBom(
              "Phat hien thieu ma bom cot " +
                idcot +
                ", ma hien tai:" +
                mabom.pump +
                " - lastInsert:" +
                GAS_DATA[idcot].currentmaBom +
                " - pos : " +
                pos
            );

            //neu isHandleMaBom = false : se lay toan bo ma bom day len, nhung tam thoi dang comment doan lay day toan bo ma bom len ma chi day ma thieu de giam tai server
            GAS_DATA[idcot].isHandleMaBom = false;

            //chi day cac ma bom thieu
            let somb = mabom.pump - GAS_DATA[idcot].currentmaBom;
            if (somb > 0) {
              for (let cnt = 1; cnt <= somb; cnt++) {
                //09/08/2021 : TRUONGNM : luu lai de cap nhat ma bom sau
                // try
                // {
                // let thongtinsaichecksum = {
                // thoigian: moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss'),
                // idcot: idcot,
                // pos: somb,
                // pump : mabom.pump - cnt,
                // currentmaBom : GAS_DATA[idcot].currentmaBom

                // };
                // //MABOM_DATA[idcot][GAS_DATA[idcot].pump] = thongtinsaichecksum;
                // MABOM_DATA[idcot].push(thongtinsaichecksum);
                // GAS_DATA[idcot].soluongmabomsaichecksum = MABOM_DATA[idcot].length;
                // writeLogMaBom("thieu ma bom add vao MABOM_DATA cot " + idcot ,thongtinsaichecksum,"so phan tu sau khi add => " +  GAS_DATA[idcot].soluongmabomsaichecksum );
                // }
                // catch(e)
                // {
                // writeLog("#error",e);
                // }

                getmabom(idcot, com, cnt);
              }
            }
            //
          }

          GAS_DATA[idcot].currentmaBom = mabom.pump;
          GAS_DATA[idcot].MaBomMoiNhat = mabom;
        } else {
          let somb = mabom.pump - GAS_DATA[idcot].currentmaBom;
          if (somb > 0) {
            writeLogMaBom(
              "Phat hien thieu ma bom cot " +
                idcot +
                ", ma hien tai:" +
                mabom.pump +
                " - lastInsert:" +
                GAS_DATA[idcot].currentmaBom +
                " - pos : " +
                pos
            );
            GAS_DATA[idcot].isHandleMaBom = false;

            //chi day cac ma bom thieu

            if (somb > 0) {
              for (let cnt = 1; cnt <= somb; cnt++) {
                getmabom(idcot, com, cnt);
              }
            }
          }
        }
        if (CONFIG.getIDCT() > 0) {
          mabom.idct = CONFIG.getIDCT();

          //07/05/20202 : TRUONGNM : Them ma bom moi nhat vao danh sach cot

          guiMaBom(mabom, com);
        } else {
          writeMaBomChuaGui(idcot, mabom.pump, mabom);
          writeLogMaBom("#mabommoi", "khong insert duoc do thieu IDCT", mabom);
        }
      } else {
        // if(pos == 0)
        // {
        // //09/08/2021 : TRUONGNM : luu lai de cap nhat ma bom sau
        // try
        // {
        // let thongtinsaichecksum = {
        // thoigian: moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss'),
        // idcot: idcot,
        // pos: pos,
        // pump : GAS_DATA[idcot].pump,
        // currentmaBom : GAS_DATA[idcot].currentmaBom,
        // data : dataInput
        // };
        // //MABOM_DATA[idcot][GAS_DATA[idcot].pump] = thongtinsaichecksum;
        // MABOM_DATA[idcot].push(thongtinsaichecksum);
        // GAS_DATA[idcot].soluongmabomsaichecksum = MABOM_DATA[idcot].length;
        // writeLogMaBom("sai checksum add vao MABOM_DATA cot " + idcot ,thongtinsaichecksum,"so phan tu sau khi add => " +  GAS_DATA[idcot].soluongmabomsaichecksum );
        // }
        // catch(e)
        // {
        // writeLog("#error",e);
        // }
        // }
      }
    }
  );
}

function getmabom(idcot, com, pos = 0) {
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDP, ...numberToByteArray(pos), 32],
    com,
    pos,
    "insertLastMaBom",
    (err, data) => {
      if (err) {
        //04.08.2021 : TRUONGNM bo doan de xem co bi lap cho nay khong: return insertLastMaBom(idcot, com, pos);
        return; // insertLastMaBom(idcot, com, pos);
      }
      let mabom = xuLyDuLieuMaBom(idcot, data, pos);
      if (mabom) {
        if (pos == 0) {
          //GAS_DATA[idcot].MaBomMoiNhat = mabom;
          //GAS_DATA[idcot].currentmaBom = mabom.pump;
        }
        writeLogMaBom(
          "#getmabom thieu ok cot " +
            idcot +
            " - pos : " +
            pos +
            ",pump: " +
            mabom.pump +
            ",currentpump: " +
            GAS_DATA[idcot].pump +
            ",currentmaBom: " +
            GAS_DATA[idcot].currentmaBom
        );
        if (CONFIG.getIDCT() > 0) {
          mabom.idct = CONFIG.getIDCT();

          //07/05/20202 : TRUONGNM : Them ma bom moi nhat vao danh sach cot

          guiMaBom(mabom, com);
        } else {
          writeMaBomChuaGui(idcot, mabom.pump, mabom);
          writeLogMaBom(
            "#getmabom thieu error",
            "khong insert duoc do thieu IDCT",
            mabom
          );
        }
      } else {
        writeLogMaBom(
          "#getmabom thieu error",
          "sai check sum hoac khong lay duoc gia"
        );
      }
    }
  );
}

function xulydulieuCaBom(data, idcot, pos = 0) {
  const subarr = [...getSubArray(data, 4, 32)];
  if (isTrustData(subarr)) {
    let metroId = subarr.shift(); //bo du tru
    let stt = bytesToInt(subarr.splice(0, 2));
    let dateBin = bytesToInt(subarr.splice(0, 4));
    let money = bytesToInt(subarr.splice(0, 4));
    let mlit = bytesToInt(subarr.splice(0, 4)); // don vi la mlit
    let dongia = bytesToInt(subarr.splice(0, 4));
    let solanbom = bytesToInt(subarr.splice(0, 2));
    let mabomcuoicungcatiep = bytesToInt(subarr.splice(0, 4));
    let tonglit = bytesToInt(subarr.splice(0, 4));
    let totalcare = bytesToInt(subarr.splice(0, 2));
    //if (saiso > 0.9 && saiso < 1.1) {
    let date = dateBinToDate(dateBin);
    let obj = {
      idcot,
      idca: stt,
      somabom: solanbom,
      mabomtiep: mabomcuoicungcatiep,
      thoigian: date,
      lit: mlit,
      thanhtien: money,
      //totaltichluy: tonglit + ((1000 - totalcare) / 1000),
      totaltichluy: tonglit,
      totalcare,
      pos,
      metroId,
      thoigiantext: moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss"),
      gia: dongia,
    };

    console.log("Xulydulieucabom", obj.idca, data);

    writeCaBom(idcot, stt, obj);
    return obj;
    // } else {
    // writeLog("#CaBom sai so qua lon", idcot, saiso)
    // }
  } else {
    writeLog("#CaBom checksumsai id", idcot, "pos", pos, subarr);
  }
  return null;
}

function handleCaBom(idcot, com, pos = 0) {
//  if (pos > 249) { //GIANG
  if (pos > 15) {
    writeLog("#CaBom Try XOng", idcot, pos);
    return;
  }
  writeLog("#CaBom Try", idcot, pos);
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32],
    com,
    pos,
    "handleCaBom",
    (err, data) => {
      //writeLogReceivedFromKIT("handleCaBom",[CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32], com,err,data);
      if (data && data[3] !== 78) {
        let obj = xulydulieuCaBom(data, idcot, pos);
        if (obj) {
          obj.idct = CONFIG.getIDCT();
          if (CONFIG.getIDCT() > 0) {
            Helper.insertCaBom(obj, (err, datais) => {
              //writeLog("#CaBom insert", idcot, pos, obj, data.toString('hex').match(/../g).join(' '))
            });
          } else {
            writeCaBomChuaGui(idcot, obj.idca, obj);
            writeLogCaBom(
              "#CaBom insert",
              "Khong insert do chua lay duoc cau hinh IDCT ",
              pos,
              obj
            );
          }
        } else {
          writeLog("#CaBom loiACK", idcot, data, pos);
          retryCaBom(idcot, com, pos);
        }
      } else if (data && data[3] === 78 && data[4] === 0x0b) {
        return writeLog("#CaBom EndofData", idcot, pos, data);
      } else {
        writeLog("#CaBom loiNAK", idcot, pos, data, pos);
        retryCaBom(idcot, com, pos);
      }
      handleCaBom(idcot, com, pos + 1);
    }
  );
}

function retryCaBom(idcot, com, pos) {
  writeLog("#CaBomRetry", idcot, pos);
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32],
    com,
    pos,
    "retryCaBom",
    (err, data) => {
      //writeLogReceivedFromKIT("retryCaBom",[CMD.STX, 0, idcot, CMD.cmdRDS, ...numberToByteArray(pos), 32], com,err,data);
      if (data && data[3] !== 78) {
        let obj = xulydulieuCaBom(data, idcot, pos);
        if (obj) {
          if (CONFIG.getIDCT() > 0) {
            obj.idct = CONFIG.getIDCT();
            Helper.insertCaBom(obj, (err, datais) => {
              writeLog(
                "#CaBomRetry insert",
                idcot,
                pos,
                obj,
                data.toString("hex").match(/../g).join(" ")
              );
            });
          } else {
            writeCaBomChuaGui(idcot, obj.idca, obj);
            writeLogCaBom(
              "#CaBomRetry",
              "Khong insert do chua lay duoc cau hinh IDCT ",
              pos,
              obj
            );
          }
        } else {
          writeLog("#CaBomRetry loiACK", idcot, pos, data, pos);
        }
      } else {
        writeLog("#CaBomRetry loiNAK", idcot, pos, data, pos);
      }
    }
  );
}

eventEmitter.on("reconnect", () => {
  writeLog("Xu ly ma bom reconnect");
  for (let i of ALL_PUMP) {
    getLoaiNhienLieu(i);
  }
});

function setThoiGianKit() {
  let date = new Date();
  //let arr=[16,16,0xff,116,0,0,7,0x19,0x19,0x19,1,0x19,0x09,0x19,1];
  let arr = [
    CMD.STX,
    0,
    0xff,
    CMD.cmdWTC,
    ...numberToByteArray(0),
    7,
    numberToBCD(date.getSeconds()),
    numberToBCD(date.getMinutes()),
    numberToBCD(date.getHours()),
    numberToBCD(date.getDay()),
    numberToBCD(date.getDate()),
    numberToBCD(date.getMonth() + 1),
    numberToBCD(date.getFullYear() - 2000),
  ];
  for (let com of CONFIG.getAllPortConnect()) {
    //writeLog("set thoi gian ", com)
    //writeLog("set thoi gian ", com);

    let lenhsetthoigian = {
      thoigianbatdau: moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss"),
      com: com,
      thoigianketthuc: null,
      msg: "Đang xử lý!",
    };
    //GAS_DATA[id].lenhsetthoigian_gannhat = lenhsetthoigian;

    GAS.sendCommand(arr, com, 0, "setThoiGianKit", (err, data) => {
      //writeLogReceivedFromKIT("setThoiGianKit", com,arr,err,data);
      // writeLog(com, err, data);
      lenhsetthoigian.msg = data;
      lenhsetthoigian.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      //GAS_DATA[id].lenhsetthoigian_gannhat = lenhsetthoigian;

      writeLog("set thoi gian : return => ", com, err, data);
    });
  }
}

function setThoiGianKit_ByKitId(i) {
  //let arr=[16,16,0xff,116,0,0,7,0x19,0x19,0x19,1,0x19,0x09,0x19,1];
  try {
    require("http").get(
      "http://servicekit.thietbixangdauhoanglong.com:8002/gettime",
      (res) => {
        res.setEncoding("utf8");
        res.on("data", function (body) {
          let dt = moment(body, "DD/MM/YYYY HH:mm:ss");
          var date = new Date(dt);

          //22/09/2020 : TRUONGNM Sua id cot dung number to array
          let arr = [
            CMD.STX,
            16,
            ...numberToByteArray(i.id, 1),
            CMD.cmdWTC,
            ...numberToByteArray(0),
            7,
            numberToBCD(date.getSeconds()),
            numberToBCD(date.getMinutes()),
            numberToBCD(date.getHours()),
            numberToBCD(date.getDay()),
            numberToBCD(date.getDate()),
            numberToBCD(date.getMonth() + 1),
            numberToBCD(date.getFullYear() - 2000),
          ];

          // let arr = [CMD.STX, 16,numberToBCD(i.id), CMD.cmdWTC, ...numberToByteArray(0), 7,
          // numberToBCD(date.getSeconds()), numberToBCD(date.getMinutes()), numberToBCD(date.getHours()),
          // numberToBCD(date.getDay()), numberToBCD(date.getDate()), numberToBCD(date.getMonth() + 1), numberToBCD(date.getFullYear() - 2000)
          // ];
          let lenhsetthoigian = {
            thoigianbatdau: moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss"),
            com: i.com,
            thoigianketthuc: null,
            msg:
              "Đang xử lý đổi tg : " +
              moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss"),
          };
          if (GAS_DATA[i.id])
            GAS_DATA[i.id].lenhsetthoigian_gannhat = lenhsetthoigian;

          //12/08/2021 : TRUONGNM sua truyen them id cot
          //GAS.sendCommand(arr, i.com,0,"setThoiGianKit", (err, data) => {
          GAS.sendCommand(arr, i.com, i.id, "setThoiGianKit", (err, data) => {
            lenhsetthoigian.thoigianketthuc = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
            if (err) {
              writeLog(
                "set thoi gian error : ( " +
                  moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss") +
                  ") return => ",
                i.com,
                i.id,
                arr,
                err,
                data
              );
              lenhsetthoigian.msg = "Lỗi:" + err;
            } else {
              writeLog(
                "set thoi gian ok ( " +
                  moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss") +
                  ") : return => ",
                i.com,
                i.id,
                err,
                data
              );
              lenhsetthoigian.msg =
                "Set thời gian thành công thành " +
                moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss");
            }
            if (GAS_DATA[i.id])
              GAS_DATA[i.id].lenhsetthoigian_gannhat = lenhsetthoigian;
          });
        });
      }
    );
  } catch (e) {
    writeLog(e);
  }

  /*set thoi gian theo may chu cua PI 
	 let date = new Date();
    let arr = [CMD.STX, 16,numberToBCD(i.id), CMD.cmdWTC, ...numberToByteArray(0), 7,
        numberToBCD(date.getSeconds()), numberToBCD(date.getMinutes()), numberToBCD(date.getHours()),
        numberToBCD(date.getDay()), numberToBCD(date.getDate()), numberToBCD(date.getMonth() + 1), numberToBCD(date.getFullYear() - 2000)
    ];
		let lenhsetthoigian = {
					thoigianbatdau: moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss'),
					com: i.com,
					thoigianketthuc: null,
				    msg: "Đang xử lý đổi tg : " + moment.parseZone(date).format('DD/MM/YYYY HH:mm:ss') 
				 };
		if(GAS_DATA[i.id])
			GAS_DATA[i.id].lenhsetthoigian_gannhat = lenhsetthoigian;
		
        GAS.sendCommand(arr, i.com,0,"setThoiGianKit", (err, data) => {
			lenhsetthoigian.thoigianketthuc = moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss');
			if(err)
			{
				writeLog("set thoi gian error : ( "+ moment.parseZone(new Date()).format('DD/MM/YYYY HH:mm:ss') +") return => ",i.com, err, data);
				lenhsetthoigian.msg =  "Lỗi:" + err;
			}
			else
			{
				writeLog("set thoi gian ok : return => ",i.com, err, data);
				lenhsetthoigian.msg =  "Set thời gian thành công thành " + moment.parseZone(date).format('DD/MM/YYYY HH:mm:ss');
			}
			if(GAS_DATA[i.id])
				GAS_DATA[i.id].lenhsetthoigian_gannhat = lenhsetthoigian;
			 
			
        });
     */
}

function dateBinToDate(dateBin) {
  let second = dateBin & 0x3f;
  let minute = (dateBin >> 6) & 0x3f;
  let hour = (dateBin >> 12) & 0x1f;
  let day = (dateBin >> 17) & 0x1f;
  let month = (dateBin >> 22) & 0x0f;
  let year = (dateBin >> 26) & 0x3f;
  let date = new Date(year + 2000, month - 1, day, hour, minute, second);
  return date;
}

//ManhLD them ham lay don gia cho ma bom dựa vào giá của ca bơm
function getDongGiaMaBomByCaBom(mabom, com) {
	console.log("#getDongGiaMaBomByCaBom===>******************",mabom, com);
  let { idca, idcot } = mabom;
  if (idca == null || idca == undefined) return null;
  let caBom = null;
  //console.log("#getDongGiaMaBomByCaBom===>",mabom,com);
  if (GAS_DATA[idcot].CaBomMoiNhat && GAS_DATA[idcot].CaBomMoiNhat.idca == idca) 
  {
	  // console.log("#getDongGiaMaBomByCaBom===>2",GAS_DATA[idcot].CaBomMoiNhat,idca);
	  // Nếu mã bơm thuôc ca bom moi nhat
	  caBom = GAS_DATA[idcot].CaBomMoiNhat;
	  //06/12/2025 : ManhLD fix khi Ca Moi Nhat Khong lay duoc don gia => lay o object hien tai
	  if(!caBom || !caBom.gia)
		  caBom = {
			  idca: idca,
			  gia: GAS_DATA[idcot].dongia
		  };
  }
    
  else if (GAS_DATA[idcot].CaBomCu)
  {
    // Nếu mã bơm thuôc ca bom cu
    caBom = GAS_DATA[idcot].CaBomCu.find((e) => e.idca == idca);
  }
  else {
    // Nếu chưa lấy được ca bom
	  //console.log("#getDongGiaMaBomByCaBom===>4Nếu chưa lấy được ca bom");
    getLastCaBom(idcot, com, 0);
  }
  
  return {
    ...mabom,
    gia: caBom ? caBom.gia : -1,
  };
}

function guiMaBom(mabom, com, cb = null, count = 0) {
	console.log("#guiMaBom===>",count,mabom);
   if (!mabom)
		return;
  let { idcot, pump } = mabom;
  if (count > 20) {
	  	console.log("#guiMaBom===>",count);
    // chờ tối đá 10 giây
    Helper.insertMaBom(mabom, (err, dt) => {
      if (dt) {
        try {
          writeMaBom(idcot, pump, mabom);
        } catch (e) {
          writeLogMaBom("#Mabom error", e);
        }
      }
	  if(mabom.gia && mabom.gia == -1)
	  {
		 // writeLogMaBom("#insert mabommoi", mabom, GAS_DATA[idcot]);
	  }
      else{
		//  writeLogMaBom("#insert mabommoi", mabom);
	  }
    });
    if (cb) cb();
	if (!cb) return; 
  }
  mabom = getDongGiaMaBomByCaBom(mabom, com);
  if (mabom && mabom.gia > 0) {
    Helper.insertMaBom(mabom, (err, dt) => {
      if (dt) {
        try {
          writeMaBom(idcot, pump, mabom);
        } catch (e) {
          writeLogMaBom("#Mabom error", e);
        }
      }
      writeLogMaBom("#insert mabommoi", mabom);
    });
    if (cb) cb();
  } else {
	  console.log("#MaBom thieu gia doi lay duoc gia tu Ca Bom");
    //writeLogMaBom("#MaBom thieu gia doi lay duoc gia tu Ca Bom");
    setTimeout(() => {
		
		if(count <21)
		{
			count = count + 1;
			guiMaBom(mabom, com, cb,count);
		}
      
    }, 500);
  }
}

let MABOM_DATA = {};
function xuLyDuLieuMaBom(idCot, dataInput, pos) {
  console.log("#xuLyDuLieuMaBom",dataInput,pos);
  const idcot = dataInput[2];
  const data = getSubArray(dataInput, 4, 32);
  if (isTrustData(data)) {
    let dateBin = bytesToInt(getSubArray(data, 0, 4));
    let money = bytesToInt(getSubArray(data, 4, 4));
    let miliLit = bytesToInt(getSubArray(data, 8, 4));
    let startTime = bytesToInt(getSubArray(data, 12, 4));
    let type = bytesToInt(getSubArray(data, 16, 1));
    let mabomhientai = bytesToInt(getSubArray(data, 17, 4));
    let id1 = bytesToInt(getSubArray(data, 21, 4)); // ma rfid nhan vien
    let id2 = bytesToInt(getSubArray(data, 25, 4)); // ma rfid khach hang
    let idca = bytesToInt(getSubArray(data, 29, 2));
	// console.log("#xuLyDuLieuMaBom_idca",bytesToInt(getSubArray(data, 29, 2)),getSubArray(data, 29, 2));
    let startTimeDate = dateBinToDate(startTime);
    let date = dateBinToDate(dateBin);

    let startTimeDate_Text = moment
      .parseZone(startTimeDate)
      .format("DD/MM/YYYY HH:mm:ss");
    let date_Text = moment.parseZone(date).format("DD/MM/YYYY HH:mm:ss");
    let mabomcu = {
      idca,
      idcot,
      date,
      money,
      mili: miliLit,
      startTime: startTimeDate,
      pos,
      pump: mabomhientai,
      type,
      id1,
      id2,
      startTimeDate_Text: startTimeDate_Text,
      date_Text: date_Text,
      gia: -1,
    };

    return mabomcu;
  } else {
    //console.log("#Mabom sai checksum", data);
    writeLogMaBom(
      "#Mabom sai checksum",
      "idcot:" +
        idcot +
        " - pos : " +
        pos +
        " - pump : " +
        GAS_DATA[idcot].pump +
        " - currentmaBom :  " +
        GAS_DATA[idcot].currentmaBom,
      dataInput
    );
    //MABOM_DATA[idcot][mabomhientai] = dataInput;
  }
  return null;
}

function writeMaBom(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./mabom/")) {
      fs.mkdirSync("./mabom/");
    }
    if (!fs.existsSync("./mabom/" + idcot)) {
      fs.mkdirSync("./mabom/" + idcot);
    }

    const path =
      "./mabom/" +
      idcot +
      "/" +
      stt +
      "_" +
      moment(obj.date).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {
    console.log("#writeMaBom", e);
    writeLog("#writeMaBom error", e);
  }
}

function writeCaBom(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./cabom/")) {
      fs.mkdirSync("./cabom/");
    }

    if (!fs.existsSync("./cabom/" + idcot)) {
      fs.mkdirSync("./cabom/" + idcot);
    }

    const path =
      "./cabom/" +
      idcot +
      "/" +
      stt +
      "_" +
      moment(obj.thoigian).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {}
}

function writeMaBomChuaGui(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./mabomchuagui/")) {
      fs.mkdirSync("./mabomchuagui/");
    }

    const path =
      "./mabomchuagui/" +
      idcot +
      "_" +
      stt +
      "_" +
      moment(obj.date).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {}
}

function writeCaBomChuaGui(idcot, stt, obj) {
  try {
    const fs = require("fs");

    if (!fs.existsSync("./cabomchuagui/")) {
      fs.mkdirSync("./cabomchuagui/");
    }

    const path =
      "./cabomchuagui/" +
      idcot +
      "_" +
      stt +
      "_" +
      moment(obj.thoigian).format("YYYYMMDD") +
      ".log";

    if (!fs.existsSync(path)) {
      fs.writeFile(
        path,
        `${JSON.stringify(obj)}`,
        { flag: "wx" },
        function (err) {
          if (err) console.error(err);
        }
      );
    } else {
      //fs.writeFileSync(path, `${JSON.stringify(obj)}`);
    }
  } catch (e) {}
}

function handleMaBom(idcot, com, pos, isWaitNAK = 0) {
  //khi lay ma bom ma NAK thi dang bom va se co ma moi=> ma hien tại -1 de lay het
  //isWaitNAK=0 la binh thuong,=1 la bat dau wait, =2 la da wait roi dang doi no duoc
  //if (pos > 330) { 	  
  if (pos > MAX_PUMP_RETRY) {	  						// line 2255 GIANG TEST

    if (GAS_DATA[idcot].getmabomthieu) {
      //cap nhat xu ly xong get ma bom
      GAS_DATA[idcot].getmabomthieu.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      GAS_DATA[idcot].getmabomthieu.msg = "Da xu ly xong get ma bom";
      GAS_DATA[idcot].getmabomthieu.pos = pos;
      GAS_DATA[idcot].getmabomthieu.runstatus = 2;
      GAS_DATA[idcot].getmabomthieu.thoigian_guilenhKIT = null;
      GAS_DATA[idcot].getmabomthieu.thoigian_KITPhanHoi = null;
      GAS_DATA[idcot].getmabomthieu.mabom = null;
      GAS_DATA[idcot].getmabomthieu.error = null;

      writeLog(
        "daylaidulieuthieuMaBom => DONE",
        com,
        GAS_DATA[idcot].getmabomthieu
      );
      //end cap nhat xu ly xong
    }

    return writeLogMaBom("#MaBom try xong", idcot, pos);
  }
  if (GAS_DATA[idcot].getmabomthieu) {
    GAS_DATA[idcot].getmabomthieu.msg =
      "Da xu ly xong get ma bom => Bat dau gui lenh xuong KIT : " + pos;
    GAS_DATA[idcot].getmabomthieu.pos = pos;
    GAS_DATA[idcot].getmabomthieu.runstatus = 1;
    GAS_DATA[idcot].getmabomthieu.thoigian_guilenhKIT = moment
      .parseZone(new Date())
      .format("DD/MM/YYYY HH:mm:ss");
  }
  GAS.sendCommand(
    [CMD.STX, 0, idcot, CMD.cmdRDP, ...numberToByteArray(pos), 32],
    com,
    pos,
    "handleMaBom",
    (err, data) => {
      //writeLogReceivedFromKIT("handleMaBom",  com,pos,err,data,isWaitNAK);
      if (GAS_DATA[idcot].getmabomthieu) {
        GAS_DATA[idcot].getmabomthieu.msg =
          "Da xu ly xong get ma bom => KIT da phan hoi : " + pos;
        GAS_DATA[idcot].getmabomthieu.thoigian_KITPhanHoi = moment
          .parseZone(new Date())
          .format("DD/MM/YYYY HH:mm:ss");
      }

      if (data && data[3] !== 78) {
        let mabom = xuLyDuLieuMaBom(idcot, data, pos);
        if (mabom) {
          if (GAS_DATA[idcot].getmabomthieu) {
            GAS_DATA[idcot].getmabomthieu.mabom = mabom;
          }

          writeLogMaBom("#handleMaBom", idcot, com, pos, mabom);
          let date = mabom.date;
          if (CONFIG.getIDCT() > 0) {
            mabom.idct = CONFIG.getIDCT();
			 writeLogMaBom("#1", mabom);
            //writeLog("#mabomcu ", mabom);
            if (
              date.getMonth() >= 0 &&
              date.getMonth() <= 12 &&
              date.getDate() > 0 &&
              date.getDate() <= 31
            ) {
			   writeLogMaBom("#guiMaBom", mabom);
              guiMaBom(mabom, com, () => {
                handleMaBom(idcot, com, pos + 1);
              });
            }else{
				 writeLogMaBom("#khongguiMaBom=>saingay", mabom);
			}
          } else {
            writeMaBomChuaGui(idcot, mabom.pump, mabom);
            writeLogMaBom(
              "#mabommoi",
              "khong insert duoc do thieu IDCT",
              mabom
            );
          }
        } else {
          if (GAS_DATA[idcot].getmabomthieu) {
            GAS_DATA[idcot].getmabomthieu.msg =
              "Da xu ly xong get ma bom => Xu ly du lieu loi";
            GAS_DATA[idcot].getmabomthieu.error = data;
          }
          writeLogMaBom("#xuLyDuLieuMaBom loi", idcot, com, pos, data);
        }
      } else if (data && data[3] === 78 && data[4] === 0x0b) {
        if (GAS_DATA[idcot].getmabomthieu) {
          GAS_DATA[idcot].getmabomthieu.msg =
            "Da xu ly xong get ma bom => Xu ly du lieu loi EndofData";
          GAS_DATA[idcot].getmabomthieu.error = data;
        }
        return writeLogMaBom("#MaBom EndofData", idcot, pos, data);
      } else {
        if (err) writeLogMaBom(err);
        else writeLogMaBom("lay mabom loi ", data, idcot, pos);
        setTimeout(() => {
          if (isWaitNAK === 1) {
            handleMaBom(idcot, com, pos - 1, 2);
          } else if (isWaitNAK == 2) {
            handleMaBom(idcot, com, pos, 2);
          } else handleMaBom(idcot, com, pos, 0);
        }, 400);
      }
    }
  );
}

function eneableWrite(id = 0xff, com, _callback) {
  //writeLogSendToKIT("eneableWrite", id,com);
  GAS.sendCommand(
    [CMD.STX, 0, id, CMD.cmdWEN],
    com,
    0,
    "eneableWrite",
    _callback
  );
}

function getAllPumpByMetroType(metro) {
  return Object.values(GAS_DATA).filter((i) => i.metroId == metro);
}

//0 cho 0xff, nếu là chốt ca thì sync
// xu ly mat dien

function chotca(id, com, callback) {
  writeLog("client chotca", id, com);
  let lenhchotca = {
    thoigianbatdau: moment.parseZone(new Date()).format("DD/MM/YYYY HH:mm:ss"),
    STX: CMD.STX,
    cmdCLS: CMD.cmdCLS,
    id: id,
    com: com,
    thoigianketthuc: null,
    msg: "Đang xử lý!",
  };
  GAS_DATA[id].lenhchotca_gannhat = lenhchotca;
  eneableWrite(id, com, (err, data) => {
    const resJson = { status: false, msg: "Xử lý thành công!" };
    if (err) {
      resJson.status = false;
      resJson.msg = `Timeout trong quá trình eneableWrite id: ${id} com: ${com}`;
      writeLog(
        "error chotca => phan hoi tu kit (#CMD.cmdACK)",
        id,
        com,
        err,
        resJson.msg
      );

      lenhchotca.msg = resJson.msg;
      lenhchotca.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      GAS_DATA[id].lenhchotca_gannhat = lenhchotca;

      // if (callback) {
      //   callback(resJson);
      //   callback = null;
      // }

      handleCMDTimeout({ id: id }, err, () => chotca(id, com, callback)); //ManhLD Retry when timeoout
    } else if (data[3] === CMD.cmdACK) {
      writeLog("gui chotca den kit", id, com);
      GAS.sendCommand(
        [CMD.STX, 0, id, CMD.cmdCLS],
        com,
        0,
        "chotca",
        (err, dt) => {
          //writeLogReceivedFromKIT("chotca",[CMD.STX, 0, id, CMD.cmdCLS],id,com,err,data);
          GAS_DATA[id].flagGetCaBom = false;

          writeLog("du lieu chotca ", dt, err);
          let status = false;
          if (dt && dt[3] === CMD.cmdACK) {
            resJson.status = true;

            resJson.msg = "Xử lý thành công!";
            lenhchotca.msg = resJson.msg;
            lenhchotca.thoigianketthuc = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
            writeLog("success chotca => ", id, com);
            GAS_DATA[id].lenhchotca_gannhat = lenhchotca;
            if (callback) {
              callback(resJson);
              callback = null;
            }
          } else {
            try {
              resJson.msg = `Device bận trong quá trình cmdCLS, mã lỗi 0x${
                dt ? dt[4] : "cc"
              },${err ? err : ""}`;
              writeLog(
                "error chotca => phan hoi tu kit (#CMD.cmdACK)",
                id,
                com,
                data,
                resJson.msg
              );
            } catch (e) {}
            lenhchotca.msg = resJson.msg;
            lenhchotca.thoigianketthuc = moment
              .parseZone(new Date())
              .format("DD/MM/YYYY HH:mm:ss");
            setTimeout(() => chotca(id, com, callback), 2500); //ManhLD thêm phần đẩy lại lệnh chốt ca
          }
        }
      );
    } else {
      resJson.status = false;
      resJson.msg = `Device bận trong quá trình cmdWEN, mã lỗi 0x${
        data ? data[4] : "cc"
      }`;

      lenhchotca.msg = resJson.msg;
      lenhchotca.thoigianketthuc = moment
        .parseZone(new Date())
        .format("DD/MM/YYYY HH:mm:ss");
      GAS_DATA[id].lenhchotca_gannhat = lenhchotca;
      writeLog(
        "error chotca=> phan hoi tu kit (#CMD.cmdACK)",
        id,
        com,
        data,
        resJson.msg
      );
      setTimeout(() => chotca(id, com, callback), 2500); //ManhLD thêm phần đẩy lại lệnh chốt ca
    }
  });
}

function changePriceMetro(metro, price, callback) {
  writeLog("client changePriceMetro", metro, price);
  let lenhdoigia = {
    thoigianbatdau: moment.parseZone(new Date()).format("DD/MM/YYYY HH:mm:ss"),
    metro: metro,
    price: price,
    thoigianketthuc: null,
    msg: "Đang xử lý!",
  };

  let pumps = getAllPumpByMetroType(metro);
  if (!pumps.length) {
    return callback("Không có cột nào với loại xăng " + metro);
  }

  let dataCallback = [];
  for (let item of pumps) {
    let msg = "";
    let { id, com } = item;
    GAS_DATA[id].lenhdoigia_gannhat = lenhdoigia;
    eneableWrite(id, com, (err, data) => {
      if (err) {
        msg = `- Timeout trong quá trình eneableWrite vòi: ${id} com: ${com}`;
        writeLog(
          "error changePriceMetro => phan hoi tu kit ",
          id,
          com,
          err,
          msg
        );
        lenhdoigia.msg = msg;
        lenhdoigia.thoigianketthuc = moment
          .parseZone(new Date())
          .format("DD/MM/YYYY HH:mm:ss");
        GAS_DATA[id].lenhdoigia_gannhat = lenhdoigia;

        dataCallback.push(msg);
        if (dataCallback.length === pumps.length) {
          callback(dataCallback.join("\n"));
        }
      } else if (data[3] === CMD.cmdACK) {
        GAS.sendCommand(
          [
            CMD.STX,
            0,
            id,
            CMD.cmdCHP,
            ...numberToByteArray(+metro),
            4,
            ...numberToByteArray(price, 4),
          ],
          com,
          0,
          "changePriceMetro",
          (err, data) => {
            //writeLogReceivedFromKIT("changePriceMetro",[CMD.STX, 0, id, CMD.cmdCHP, ...numberToByteArray(+metro), 4, ...(numberToByteArray(price, 4))],id,com,err,data);
            if (data && data[3] === CMD.cmdACK) {
              let obj = GAS_DATA[id];
              if (!obj) {
                obj = GAS_DATA[id] = { timeOut: 0 };
              }

              msg = `- Thay đổi giá ${CONFIG.getMetroName(
                metro
              )} vòi:${id} thành công! `;
              writeLog(
                "success changePriceMetro => phan hoi tu kit",
                id,
                com,
                msg
              );
              lenhdoigia.msg = msg;
              lenhdoigia.thoigianketthuc = moment
                .parseZone(new Date())
                .format("DD/MM/YYYY HH:mm:ss");
              GAS_DATA[id].lenhdoigia_gannhat = lenhdoigia;

              obj.flagGetFullUpdate = true;
              dataCallback.push(msg);
              if (dataCallback.length === pumps.length) {
                callback(dataCallback.join("\n"));
              }
            } else {
              msg = `- Thay đổi giá ${CONFIG.getMetroName(
                metro
              )} vòi:${id} thất bại, bạn phải chốt ca trước khi đổi giá! Mã lỗi: 0x${
                data ? data[4] : "cc"
              },${err ? err : ""}`;
              lenhdoigia.msg = msg;
              lenhdoigia.thoigianketthuc = moment
                .parseZone(new Date())
                .format("DD/MM/YYYY HH:mm:ss");
              GAS_DATA[id].lenhdoigia_gannhat = lenhdoigia;
              writeLog(
                "error changePriceMetro => phan hoi tu kit ",
                id,
                com,
                data,
                msg
              );
              dataCallback.push(msg);
              if (dataCallback.length === pumps.length) {
                callback(dataCallback.join("\n"));
              }
            }
          }
        );
      } else {
        msg = `- Timeout trong quá trình eneableWrite vòi:${id}  Mã lỗi: 0x${
          data ? data[4] : "cc"
        }`;
        writeLog(
          "error changePriceMetro => phan hoi tu kit (#CMD.cmdACK)",
          id,
          com,
          data,
          msg
        );
        lenhdoigia.msg = msg;
        lenhdoigia.thoigianketthuc = moment
          .parseZone(new Date())
          .format("DD/MM/YYYY HH:mm:ss");
        GAS_DATA[id].lenhdoigia_gannhat = lenhdoigia;
        dataCallback.push(msg);
        if (dataCallback.length === pumps.length) {
          callback(dataCallback.join("\n"));
        }
      }
    });
  }
}

function getDebugData(type = 0) {
  let gas = GAS.getDebugData(0);

  return gas;
}

function getQUEUE_PENDING(type = 0) {
  let gas = GAS.getQUEUE_PENDING(0);

  return gas;
}

function getQUEUE_SEND_TO_KIT_V2(type = 0) {
  let gas = GAS.getQUEUE_SEND_TO_KIT_V2(0);

  return gas;
}

function getQUEUE_SEND_TO_KIT(type = 0) {
  let gas = GAS.getQUEUE_SEND_TO_KIT(0);

  return gas;
}

module.exports = {
  ver,
  ver_releasedate,
  daylaidulieuthieuCa,
  daylaidulieuthieuCaBom,
  daylaidulieuthieuMaBom,
  daylaidulieuKIT,
  daylaidulieuthieu,
  getGasData,
  getAllPumpByMetroType,
  changePriceMetro,
  CONFIG,
  chotca,
  getDebugData,
  getQUEUE_SEND_TO_KIT,
  getQUEUE_SEND_TO_KIT_V2,
  getQUEUE_PENDING,
};
