const { SerialPort } = require("serialport"); //ManhLD sua update version SerialPort 12.0.0 12/05/2024
const Parser = require("./Parser");
const net = require("net");
const { CMD, ADDR, StatusBom } = require("./const");
const CONFIG = require("./config");
const COM_OBJ = {};
const utils = require("./utils");
// Create an EventEmitter object
const eventEmitter = require("./eventEmitter");
const QUEUE_SEND_TO_KIT = {};
const parObj = new Parser();
const {
  writeLog,
  writeLogChotCa,
  writeLogDoiGia,
  writeLogMaBom,
  writeLogReceivedFromKIT,
  writeLogSendToKIT,
  writeLogQueue,
  writeLogPROCESSQUEUEKIT,
} = require("./logThread");
const moment = require("moment");
(() => {
  let allPump = CONFIG.getAllPump();
  let arr = [];
  for (let cotbom of allPump) {
    if (!arr.includes(cotbom.com)) {
      atempConnectPort(cotbom);
      arr.push(cotbom.com);
    }
  }
})();

let timeOutPortWrite = null;

//ManhLD them ham open port 12/05/2024
function openPort(port, com) {
  port.open(function (err) {
    console.log("Port Open");
    if (err) {
      eventEmitter.emit("errorClient", err.message);
      setTimeout(() => {
        atempConnectPort(pump, true);
      }, 2000);
      return console.log("Error opening port: ", err.message);
    }
    readyCom(com);
  });
}

function atempConnectPort(pump, isReconnect = false) {
  let { type, com, ip, portTCP } = pump;
  const i = com;
  let port;
  switch (type) {
    case CONFIG.TYPE_PORT_CONFIG.TCP: {
      port = new net.Socket();
      port.connect(portTCP, ip, () => {
        writeLog("connected to server!");
        readyCom(com);
      });
      port.on("end", (e) => {
        writeLog("end", e);
        setTimeout(() => {
          atempConnectPort(pump, true);
        }, 2000);
      });
      port.on("error", (err) => {
        writeLog("error", err);
        atempConnectPort(pump, true);
      });
      break;
    }
    case CONFIG.TYPE_PORT_CONFIG.COM: {
      port = new SerialPort({
        path: com,
        baudRate: 19200,
        autoOpen: false,
      });
      openPort(port, com);
      port.on("error", (err) => {
        console.log("Port Open error");
        writeLog("error opening port: ", err.message);
        // console.log('error opening port: ', err.message)
        atempConnectPort(pump, true);
      });
      port.on("close", function (disconnectError) {
        console.log("Port Closed");
        let exec = require("child_process").exec;
        //let command = "serialport-list";
        //exec(command, function (error, stdout, stderr) {
        //  //writeLogPROCESSQUEUEKIT("Port available: ", stdout);
        //});
        writeLogPROCESSQUEUEKIT("Port close", com, disconnectError);
        setTimeout(() => {
          openPort(port, com);
        }, 1500);
      });
      break;
    }
  }
  const parser = port.pipe(parObj);
  parser.on("data", (data) => {
    //tra ve tu kit : dua vao cmd_id
    // console.log("parser", data.length)
    try {
      const ID_PUMP = data[2];
      const CMD_ID = data[data.length - 2];
      //writeLogReceivedFromKIT("ID_PUMP:" + ID_PUMP,"CMD_ID:" + CMD_ID,data);

      let cb = COM_OBJ[i].callbackQueue[ID_PUMP]
        ? COM_OBJ[i].callbackQueue[ID_PUMP][CMD_ID]
        : null;

      if (cb) {
        clearTimeout(cmdTimeOut[com][CMD_ID]);
        try {
          cb(null, data);
          delete COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
          setTimeout(() => {
            //console.log("parser", "gui tiep");
            readyCom(com);
          }, 150);
        } catch (e) {
          console.log(e);
          writeLog("error on parser data :", e, data);
        }
      } else {
        //writeLog("khong co callbackdoi", data)
      }
    } catch (e) {
      console.log(e);
      writeLog("error on parser data :", e, data);
    }
  });
  if (!COM_OBJ[com])
    COM_OBJ[com] = {
      CMD_ID: 0, /// lay cmdid day vao queue
      CMD_ID_NOW: 0, // cmd id dang gui
      port,
      isReady: true,
      callbackQueue: {},
    };
}

/*
 * lưu list theo com và cmd id ví dụ obj={"COM3":{"1":[Buffer],"2":[Buffer]}}
 *
 * */
function isTrustDataDebug(arr) {
  if (!arr || arr.length < 5) {
    return false;
  }
  let total = arr.reduce((sum, i) => (sum += i), 0);
  return (total & 0xff) === 0;
}

function deleteKeyCallback(com, CMD_ID, ID_PUMP = "") {
  delete COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
  if (
    QUEUE_PENDING[com] &&
    QUEUE_PENDING[com][ID_PUMP] &&
    QUEUE_PENDING[com][ID_PUMP][CMD_ID] &&
    QUEUE_PENDING[com][ID_PUMP][CMD_ID].length
  ) {
    try {
      const obj = QUEUE_PENDING[com][ID_PUMP][CMD_ID].shift();
      //writeLog("day qua han", obj.com, obj.arr);
      QUEUE_SEND_TO_KIT[com].push({ arr: obj.arr, com: obj.com });
      let { callbackQueue } = COM_OBJ[com];
      callbackQueue[ID_PUMP][CMD_ID] = obj.callback;
    } catch (e) {
      writeLog("deleteKeyCallback", e, arguments);
    }
  }
}

function numberToByteArray(/*long*/ number) {
  // we want to represent the input as a 8-bytes array
  let byteArray = [];
  while (number != 0) {
    const byte = number & 0xff;
    byteArray.push(byte);
    number = (number - byte) / 256;
  }
  return byteArray;
}

const QUEUE_PENDING = {};

function sendCommandDebug(hex, com, callback) {
  try {
    let arr = numberToByteArray(hex).reverse();
    if (isTrustDataDebug(arr)) {
      const ID_PUMP = arr[1];
      const CMD_ID = arr[arr.length - 2];
      if (CMD_ID != 255) {
        callback(`CMD ID phải là 255, hiện tại = ${cmd}`);
        return;
      }
      let { port, callbackQueue } = COM_OBJ[com];
      if (!callbackQueue[ID_PUMP]) {
        callbackQueue[ID_PUMP] = {};
      }
      if (callbackQueue[ID_PUMP][CMD_ID]) {
        // khi con thi dua vao queue
        if (!QUEUE_PENDING[com]) {
          QUEUE_PENDING[com] = {};
        }
        if (!QUEUE_PENDING[com][ID_PUMP]) {
          QUEUE_PENDING[com][ID_PUMP] = {};
        }
        if (QUEUE_PENDING[com][ID_PUMP][CMD_ID]) {
          QUEUE_PENDING[com][ID_PUMP][CMD_ID].push({ arr, callback, com });
        } else {
          QUEUE_PENDING[com][ID_PUMP][CMD_ID] = [{ arr, callback, com }];
        }
        // callbackQueue[ID_PUMP][CMD_ID]("Qua han", null);
      } else {
        callbackQueue[ID_PUMP][CMD_ID] = callback;
        if (!QUEUE_SEND_TO_KIT[com]) {
          QUEUE_SEND_TO_KIT[com] = [];
        }
        QUEUE_SEND_TO_KIT[com].push({ arr, com });
      }
    } else {
      callback(`Data không nhận dạng được [${arr.join(", ")}]`);
    }
  } catch (e) {
    callback(e);
  }
  //arr bo CMDID va checksum;
}

const QUEUE_SEND_TO_KIT_V2 = {};
function sendCommand(arr, com, pos, loai, callback) {
  const CMD_TYPE = arr[3];
  if (!QUEUE_SEND_TO_KIT_V2[com]) {
    QUEUE_SEND_TO_KIT_V2[com] = { normal: [], special: [] };
  }
  //arr bo CMDID va checksum;
  if (arr[1] !== 0) {
    console.warn("cnt = 0 vi tu tinh roi");
  }
  const ID_PUMP = arr[2];
  arr[1] = arr.length + 2; //cnt
  let { port, CMD_ID, callbackQueue } = COM_OBJ[com];

  COM_OBJ[com].CMD_ID = CMD_ID % 200;
  if (!callbackQueue[ID_PUMP]) {
    callbackQueue[ID_PUMP] = {};
  }
  arr.push(CMD_ID);
  COM_OBJ[com].CMD_ID += 1;
  let checksum = (0 - arr.reduce((a, b) => a + b, 0)) & 0xff;
  arr.push(checksum);
  if (
    CMD_TYPE == CMD.cmdFUP ||
    CMD_TYPE == CMD.cmdSTA ||
    CMD_TYPE == CMD.cmdINF ||
    CMD_TYPE == CMD.cmdQUP ||
    loai == "logoff"
  ) {
    if (!QUEUE_SEND_TO_KIT_V2[com].normal) {
      QUEUE_SEND_TO_KIT_V2[com].normal = [];
    }

    let InsertQueueTime = moment(Date.now()).format("DD-MM-YYYY HH:mm:ss");

    let arrQ = QUEUE_SEND_TO_KIT_V2[com].normal.filter(
      (command) =>
        command.loai == loai && command.pos == pos && command.arr[2] == ID_PUMP
    );

    if (arrQ.length < 1) {
      QUEUE_SEND_TO_KIT_V2[com].normal.push({
        arr,
        callback,
        com,
        InsertQueueTime,
        loai,
        pos,
      });
      //writeLogQueue("normal",{arr, callback, com,InsertQueueTime,loai,pos});
    } else {
      // writeLogQueue("normal","khong addd queue da ton tai : loai : " + loai + ", pos : " + pos + ", ID_PUMP : " + ID_PUMP);
    }
    // const john = QUEUE_SEND_TO_KIT_V2[com].normal.find(command => command.loai === loai &&);
  } else {
    if (!QUEUE_SEND_TO_KIT_V2[com].special) {
      QUEUE_SEND_TO_KIT_V2[com].special = [];
    }
    let InsertQueueTime = moment(Date.now()).format("DD-MM-YYYY HH:mm:ss");
    //check neu la chot ca thi cho vao dau queue :
    if (
      loai == "changePriceMetro" ||
      loai == "chotca" ||
      loai == "eneableWrite" ||
      loai == "hanmuc"
    ) {
      QUEUE_SEND_TO_KIT_V2[com].special.unshift({
        arr,
        callback,
        com,
        InsertQueueTime,
        loai,
        pos,
      });
    } else if (loai == "setThoiGianKit") {
      let arrQ = QUEUE_SEND_TO_KIT_V2[com].special.filter(
        (command) => command.loai == loai && command.arr[2] == ID_PUMP
      );
      if (arrQ.length > 0) {
        arrQ.forEach((element) => {
          let index = QUEUE_SEND_TO_KIT_V2[com].special.indexOf(element);
          if (index > -1) {
            QUEUE_SEND_TO_KIT_V2[com].special.splice(index, 1);
          }
        });
      }

      QUEUE_SEND_TO_KIT_V2[com].special.unshift({
        arr,
        callback,
        com,
        InsertQueueTime,
        loai,
        pos,
      });
    } else {
      let arrQ = QUEUE_SEND_TO_KIT_V2[com].special.filter(
        (command) =>
          command.loai == loai &&
          command.pos == pos &&
          command.arr[2] == ID_PUMP
      );
      if (arrQ.length < 1) {
        if (loai == "insertLastMaBom" || loai == "getLastCaBom") {
          QUEUE_SEND_TO_KIT_V2[com].special.unshift({
            arr,
            callback,
            com,
            InsertQueueTime,
            loai,
            pos,
          });
        } else {
          QUEUE_SEND_TO_KIT_V2[com].special.push({
            arr,
            callback,
            com,
            InsertQueueTime,
            loai,
            pos,
          });
        }
      }
      // else{
      // 	 //writeLogQueue("special","khong addd queue da ton tai : loai : " + loai + ", pos : " + pos + ", ID_PUMP : " + ID_PUMP);
      // }
    }

    //writeLogQueue("special",{arr, callback, com,InsertQueueTime,loai,pos});
  }
}

const cmdTimeOut = {};
let checkSendCout = 0;

function readyCom(com) {
  let buffer;
  try {
    if (QUEUE_SEND_TO_KIT_V2[com] != undefined) {
      if (
        checkSendCout % 2 == 0 &&
        QUEUE_SEND_TO_KIT_V2[com].special &&
        QUEUE_SEND_TO_KIT_V2[com].special.length
      ) {
        buffer = QUEUE_SEND_TO_KIT_V2[com].special.shift();
      } else {
        buffer = QUEUE_SEND_TO_KIT_V2[com].normal.shift();
      }
    }
  } catch (e) {
    console.log(e);
  }

  if (buffer) {
    checkSendCout = (checkSendCout + 1) % 500;
    let { arr, com, callback } = buffer;
    try {
      const ID_PUMP = arr[2];
      const CMD_ID = arr[arr.length - 2];
      const send = Buffer.from(arr);
      //writeLogPROCESSQUEUEKIT("readyCom_port.write:loai:" + buffer.loai + ", idcot : " + ID_PUMP + ", InsertQueueTime : " + buffer.InsertQueueTime  + ", CMD_ID : " + CMD_ID + ", COM : " + buffer.com + ", pos : " + buffer.pos);
      //

      //writeLogSendToKIT(buffer);

      if (COM_OBJ[com]) {
        //ManhLD them phan set time out cho port .write
        if (timeOutPortWrite) clearTimeout(timeOutPortWrite);
        timeOutPortWrite = setTimeout(() => {
          writeLogPROCESSQUEUEKIT("timeOutPortWrite");
          //writeLogPROCESSQUEUEKIT(`timeOutPortWrite status ${COM_OBJ[com].port.isOpen()}`);
          //atempConnectPort(com, true);
          //13.05.2023 truong them

          //end
          readyCom(com);
        }, 1500);
        COM_OBJ[com].port.write(send, (err) => {
          if (timeOutPortWrite) clearTimeout(timeOutPortWrite);
          timeOutPortWrite = null;
          //writeLogPROCESSQUEUEKIT("vao hanm COM_OBJ[com].port.write ");
          try {
            COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID] = callback;
          } catch (e) {
            console.log(e);
          }
          if (err) {
            try {
              console.log(err);
              writeLog(err);
              //khong gui dc
              const ID_PUMP = arr[2];
              if (!COM_OBJ[com].callbackQueue[ID_PUMP]) {
                COM_OBJ[com].callbackQueue[ID_PUMP] = {};
              }
              let cb = COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
              if (cb) {
                writeLogPROCESSQUEUEKIT(
                  "ERROR:loai:" +
                    buffer.loai +
                    ", idcot : " +
                    ID_PUMP +
                    ", InsertQueueTime : " +
                    buffer.InsertQueueTime +
                    ", CMD_ID : " +
                    CMD_ID +
                    ", COM : " +
                    buffer.com +
                    ", pos : " +
                    buffer.pos +
                    "=> RETURN:" +
                    `ERR CMDID:${CMD_ID}, data:[${send
                      .toString("hex")
                      .match(/../g)
                      .join(" ")}],${com}}, ${String(err)}`
                );
                cb(
                  `ERR CMDID:${CMD_ID}, data:[${send
                    .toString("hex")
                    .match(/../g)
                    .join(" ")}],${com}}, ${String(err)}`
                );
                delete COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];

                clearTimeout(cmdTimeOut[com][CMD_ID]);
                setTimeout(() => {
                  readyCom(com);
                }, 150);
              }
            } catch (e) {
              writeLogPROCESSQUEUEKIT("readyCom_error_1", e);

              setTimeout(() => {
                readyCom(com);
              }, 150);
            }
          } else {
            try {
              //writeLogPROCESSQUEUEKIT("SUCCESS:loai:" + buffer.loai + ", idcot : " + ID_PUMP + ", InsertQueueTime : " + buffer.InsertQueueTime  + ", CMD_ID : " + buffer.CMD_ID + ", COM : " + buffer.com + ", pos : " + buffer.pos );

              //gui dc
              let timer = setTimeout(() => {
                if (!COM_OBJ[com].callbackQueue[ID_PUMP]) {
                  COM_OBJ[com].callbackQueue[ID_PUMP] = {};
                }
                let cb = COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
                if (cb) {
                  writeLogPROCESSQUEUEKIT(
                    "SUCCESS NHUNG TimeoutCallbackQueue:loai:" +
                      buffer.loai +
                      ", idcot : " +
                      ID_PUMP +
                      ", InsertQueueTime : " +
                      buffer.InsertQueueTime +
                      ", CMD_ID : " +
                      buffer.CMD_ID +
                      ", COM : " +
                      buffer.com +
                      ", pos : " +
                      buffer.pos +
                      "=> RETURN:" +
                      `Timeout CMDID:${CMD_ID}, data:[${send
                        .toString("hex")
                        .match(/../g)
                        .join(" ")}],${com}}, ${
                        Object.values(COM_OBJ[com].callbackQueue[ID_PUMP])
                          .length
                      },${parObj.getBufferSize()}`
                  );
                  const str = `Timeout CMDID:${CMD_ID}, data:[${send
                    .toString("hex")
                    .match(/../g)
                    .join(" ")}],${com}}, ${buffer.pos}, ${buffer.loai}, ${
                    Object.values(COM_OBJ[com].callbackQueue[ID_PUMP]).length
                  },${parObj.getBufferSize()}`;
                  cb(str);
                  writeLog(str);
                  delete COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
                  readyCom(com);
                } else {
                  delete COM_OBJ[com].callbackQueue[ID_PUMP][CMD_ID];
                  readyCom(com);
                }
              }, 1500);
              if (cmdTimeOut[com]) {
                cmdTimeOut[com][CMD_ID] = timer;
              } else {
                cmdTimeOut[com] = {};
                cmdTimeOut[com][CMD_ID] = timer;
              }
            } catch (e) {
              writeLogPROCESSQUEUEKIT("readyCom_error_2", e);
              setTimeout(() => {
                readyCom(com);
              }, 150);
            }
          }
        });
      } else {
        writeLogPROCESSQUEUEKIT("COM_OBJ[" + com + "].port null");
        setTimeout(() => {
          readyCom(com);
        }, 150);
      }
    } catch (e) {
      writeLogPROCESSQUEUEKIT("readyCom_error__3", e);
      setTimeout(() => {
        readyCom(com);
      }, 150);
    }
  } else {
    setTimeout(() => {
      readyCom(com);
    }, 150);
  }
}

function getComConnect() {
  return Object.keys(COM_OBJ);
}

function getDebugData(type = 0) {
  //0 la arr, != la obj
  if (type !== 0) {
    return QUEUE_SEND_TO_KIT_V2;
  }
  return Object.values(QUEUE_SEND_TO_KIT_V2);
}

function getQUEUE_SEND_TO_KIT_V2(type = 0) {
  //0 la arr, != la obj
  if (type !== 0) {
    return QUEUE_SEND_TO_KIT_V2;
  }
  return Object.values(QUEUE_SEND_TO_KIT_V2);
}
function getQUEUE_SEND_TO_KIT(type = 0) {
  //0 la arr, != la obj
  if (type !== 0) {
    return QUEUE_SEND_TO_KIT;
  }
  return Object.values(QUEUE_SEND_TO_KIT);
}
function getQUEUE_PENDING(type = 0) {
  //0 la arr, != la obj
  if (type !== 0) {
    return QUEUE_PENDING;
  }
  return Object.values(QUEUE_PENDING);
}
module.exports = {
  sendCommand,
  atempConnectPort,
  sendCommandDebug,
  getComConnect,
  getDebugData,
  getQUEUE_SEND_TO_KIT,
  getQUEUE_SEND_TO_KIT_V2,
  getQUEUE_PENDING,
};
